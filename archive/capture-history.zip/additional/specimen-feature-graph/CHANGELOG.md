# Changelog

## 2026-09-15 - Butterfly subset v1 (590 specimens)
- Sampled 10 random specimens from each of 58 NHM British butterfly species
  folders into `data/butterflies/` with a manifest (barcode = specimen ID).
- Added a Lepidoptera extension to the observation vocabulary (eyespots,
  margin pattern, tails, surface shown, apex marking, three ranked wing
  colours) and a deterministic normalisation step that downgrades negative
  claims without clear visibility, or mismatched counts, to unknown and
  records the change.
- Species, trait-value, range-cell nodes and top-3 measured colour edges in
  the graph; parallel observer workers; ingest skips unreadable files.
- GBIF GB+IE occurrence fetch per species for range cells and simulated
  specimen localities (labelled as simulated on every record).
- Viewer rewritten: colour/trait/species filters, thumbnails, and an offline
  British Isles map (Natural Earth 50m) linked to the graph selection.
- Claude CLI smoke test on two crops succeeded; batch 1 (268) and batch 2
  (322) running with 4-5 workers. Prompt tightened so eyespot counts of zero
  carry wing-area evidence; `revalidate` command repairs earlier structural
  slips from saved raw responses (79 of 84 repaired without new model calls).
- Final subset: 59 species x 10 = 590 specimens; surplus copies parked in
  `images_unused/`. Sampler and manifest builder retry iCloud timeouts.
- All 590 specimens have usable observations after two batches, one retry
  pass and revalidation (14 superseded failed runs kept as evidence). Final
  graph built to `outputs_butterflies/`; 24 tests pass.
- Viewer checked in Chrome: force layout stabilised (clamped forces, hub
  damping), analysis layer and map-only node kinds off by default, colour
  filter highlights specimens in graph and map with per-species thumbnails.

## 2026-09-15 - Pipeline v0.1
- Read openscan-specimen-lab via GitHub API (no clone): observation contract,
  evidence store, provider adapters, graph and JSON-LD export, ROI heuristic.
- Built `specimen_graph` package: content-hashed store with JSON records,
  model-free descriptors (border-background Otsu mask with recorded fallback,
  shape/Hu moments, Lab colour k-means mapped to the openscan colour
  vocabulary, texture, pHash/dHash), vendored `specimen-features-v1` contract
  with Claude/Codex/local/dry-run adapters, permissive location CSV loader
  with haversine distances and grid/country regions, networkx graph builder
  with evidence and analysis layers, exports (graph JSON, JSON-LD, GraphML,
  GEXF, CSV, specimen projection), offline canvas viewer, report with
  communities and optional seeded Mantel test.
- Synthetic demo generator with adversarial cases (labels, pins, scale bars,
  gradients, second views, missing location, duplicate file, empty frame).
- Validation: demo run gives 67 nodes / 151 edges; 24 pytest tests pass.
- Conda env creation blocked by train wifi; fallback env `nhm-specimen-counter`
  used for the first run.
