"""Optional vision-language observations, one run per specimen.

Providers: ``claude`` (Claude CLI, signed in), ``codex`` (Codex CLI), ``local``
(OpenAI-compatible endpoint via SPECIMEN_LOCAL_VLM_URL / _MODEL / _API_KEY),
``dry-run`` (writes prompt and schema, calls nothing). Every attempt is kept
under ``store/runs/<run_id>/`` with the prompt, schema, raw response and a
terminal record; only validated runs are used by the graph.
"""

from __future__ import annotations

import base64
import hashlib
import json
import mimetypes
import os
import shutil
import subprocess
import time
from urllib.request import Request, urlopen

from .contract import FEATURES, VERSION, canonical, output_schema, prompt, validate
from .store import Store, digest, now, uid, write_new

PROVIDERS = {
    "claude": {"label": "Claude CLI", "model": "sonnet"},
    "codex": {"label": "Codex CLI", "model": "gpt-6-astra"},
    "local": {"label": "Local OpenAI-compatible VLM", "model": None},
    "dry-run": {"label": "Write prompt only", "model": "none"},
}


def available(provider_id: str) -> bool:
    if provider_id == "claude":
        return bool(shutil.which("claude"))
    if provider_id == "codex":
        return bool(shutil.which("codex"))
    if provider_id == "local":
        return bool(os.environ.get("SPECIMEN_LOCAL_VLM_URL") and os.environ.get("SPECIMEN_LOCAL_VLM_MODEL"))
    return provider_id == "dry-run"


def image_blocks(store: Store, image_ids, style: str) -> list[dict]:
    blocks = []
    for image_id in image_ids:
        path = store.image_path(image_id, verify=True)
        mime = mimetypes.guess_type(path)[0] or "image/jpeg"
        data = base64.b64encode(path.read_bytes()).decode()
        if style == "claude":
            blocks.append({"type": "image", "source": {"type": "base64", "media_type": mime, "data": data}})
        else:
            blocks.append({"type": "image_url", "image_url": {"url": f"data:{mime};base64,{data}"}})
    return blocks


def begin_run(store: Store, specimen_id: str, image_ids: list[str], provider_id: str, model: str) -> dict:
    images = [store.image(i) for i in image_ids]
    if not images or any(i["specimen_id"] != specimen_id for i in images) or len(set(image_ids)) != len(image_ids):
        raise ValueError("A run needs unique images of one specimen")
    schema = output_schema(image_ids)
    text = prompt(images) + "\nRequired response JSON schema:\n" + canonical(schema) + \
        "\nReturn the complete JSON object as text with every required key. No markdown fences.\n"
    run = {"id": uid("run"), "specimen_id": specimen_id, "image_ids": image_ids, "provider": provider_id,
           "model": model, "created": now(), "schema_version": VERSION, "schema_sha256": digest(schema),
           "vocabulary_sha256": digest(FEATURES), "prompt_sha256": hashlib.sha256(text.encode()).hexdigest(),
           "images": images}
    folder = store.run_dir(run["id"])
    write_new(folder / "request.json", (canonical(run) + "\n").encode())
    write_new(folder / "schema.json", (canonical(schema) + "\n").encode())
    write_new(folder / "prompt.txt", text.encode())
    return run


def normalise(payload: dict) -> list[str]:
    """Deterministic downgrades that keep the contract's evidence rules without
    discarding a whole run: a negative anatomical claim without clear visibility,
    or a count whose instance IDs do not match, becomes ``unknown``. Every change
    is returned so it can be recorded next to the raw response."""
    changes = []
    if not isinstance(payload, dict) or not isinstance(payload.get("observations"), list):
        return changes
    for o in payload["observations"]:
        if not isinstance(o, dict):
            continue
        f = FEATURES.get(o.get("feature_id"))
        if f is None:
            continue
        if o.get("status") in ("unknown", "not_applicable"):
            if o.get("value") is not None:
                o["value"] = None
                changes.append(f"{o['feature_id']}: cleared value on an unresolved observation")
            if not (o.get("note") or "").strip():
                o["note"] = "[auto: observer gave no reason]"
                changes.append(f"{o['feature_id']}: added placeholder reason to an unresolved observation")
            continue
        if o.get("status") != "observed":
            continue
        reason = None
        if not o.get("evidence"):
            reason = "observed claim without image evidence"
        elif o.get("value") is False and f["category"] != "quality" and o.get("visibility") != "clear":
            reason = "negative claim without clear visibility"
        elif f["kind"] == "count" and isinstance(o.get("value"), int):
            instances = {e.get("instance_id") for e in o.get("evidence", []) if isinstance(e, dict) and e.get("instance_id")}
            if len(instances) != o["value"]:
                reason = f"count {o['value']} not matched by {len(instances)} instance IDs"
            elif (o["feature_id"] == "legs.total_count" or o["value"] == 0) and o.get("visibility") != "clear":
                reason = "total or zero count without clear visibility"
        if reason:
            o["status"], o["value"] = "unknown", None
            o["note"] = (o.get("note") or "").strip() + f" [auto-downgraded to unknown: {reason}]"
            changes.append(f"{o['feature_id']}: {reason}")
    return changes


def finish_run(store: Store, run: dict, raw: str, *, error: str | None = None, telemetry: dict | None = None,
               state: str | None = None) -> dict:
    """States: usable (validated), failed (invalid/rejected), unavailable (no provider), dry_run."""
    folder = store.run_dir(run["id"])
    write_new(folder / "raw-response.txt", raw.encode())
    errors, payload, normalisations = [], None, []
    try:
        payload = json.loads(raw)
        normalisations = normalise(payload)
        errors = validate(payload, run["image_ids"])
    except (ValueError, TypeError) as exc:
        errors.append(f"response is not valid JSON: {exc}")
    if error:
        errors.append(error)
    terminal = {"finished": now(), "errors": errors, "normalisations": normalisations, "telemetry": telemetry or {},
                "raw_sha256": hashlib.sha256(raw.encode()).hexdigest(),
                "state": state or ("failed" if errors else "usable"), "semantic_accuracy": "unverified"}
    write_new(folder / "terminal.json", (canonical(terminal) + "\n").encode())
    if not errors:
        write_new(folder / "result.json", (canonical(payload) + "\n").encode())
    return {**run, "terminal": terminal, "result": payload if not errors else None}


def _claude(store, run, timeout):
    folder = store.run_dir(run["id"])
    work = folder / "empty-workdir"
    work.mkdir()
    command = ["claude", "-p", "--tools", "", "--disable-slash-commands", "--strict-mcp-config",
               "--mcp-config", '{"mcpServers":{}}', "--no-session-persistence", "--model", run["model"],
               "--input-format", "stream-json", "--output-format", "stream-json", "--verbose",
               "--system-prompt", "You are an image observer. Return the requested structured observation as JSON text only. Use only supplied image content; do not use tools or infer hidden anatomy."]
    write_new(folder / "execution.json", (canonical({"argv": command, "timeout_seconds": timeout}) + "\n").encode())
    content = [{"type": "text", "text": (folder / "prompt.txt").read_text()}, *image_blocks(store, run["image_ids"], "claude")]
    payload = (canonical({"type": "user", "message": {"role": "user", "content": content}}) + "\n").encode()
    if len(payload) > 9_500_000:
        raise ValueError("Image payload exceeds the Claude CLI budget; use fewer or smaller images")
    proc = subprocess.run(command, cwd=work, input=payload, capture_output=True, timeout=timeout)
    write_new(folder / "events.jsonl", proc.stdout)
    write_new(folder / "stderr.log", proc.stderr)
    raw, errors, models, usage = "", [], set(), {}
    for line in proc.stdout.decode(errors="replace").splitlines():
        if not line.strip():
            continue
        try:
            event = json.loads(line)
        except ValueError:
            errors.append("malformed event line")
            continue
        if event.get("type") == "assistant":
            message = event.get("message", {})
            if message.get("model"):
                models.add(message["model"])
            for block in message.get("content", []):
                if block.get("type") == "tool_use":
                    errors.append("unexpected tool use: " + str(block.get("name")))
        if event.get("type") == "result":
            usage = event.get("usage", {})
            if event.get("is_error") or event.get("subtype") != "success":
                errors.append("Claude did not return a successful result")
            raw = canonical(event["structured_output"]) if event.get("structured_output") is not None else event.get("result", "")
    if proc.returncode:
        errors.append(f"Claude exit code {proc.returncode}")
    return strip_fences(raw), "; ".join(errors) or None, {"models": sorted(models), "usage": usage}


def _codex(store, run, timeout):
    folder = store.run_dir(run["id"])
    work = folder / "empty-workdir"
    work.mkdir()
    out = folder / "emitted-response.txt"
    command = ["codex", "exec", "--skip-git-repo-check", "--sandbox", "read-only", "--model", run["model"],
               "-C", str(work), "--color", "never", "--output-schema", str(folder / "schema.json"), "-o", str(out)]
    for image_id in run["image_ids"]:
        command.extend(["--image", str(store.image_path(image_id, verify=True))])
    command.append("-")
    write_new(folder / "execution.json", (canonical({"argv": command, "timeout_seconds": timeout}) + "\n").encode())
    proc = subprocess.run(command, input=(folder / "prompt.txt").read_bytes(), capture_output=True, timeout=timeout)
    write_new(folder / "stdout.log", proc.stdout)
    write_new(folder / "stderr.log", proc.stderr)
    raw = out.read_text() if out.exists() else ""
    return strip_fences(raw), (f"Codex exit code {proc.returncode}" if proc.returncode else None), {}


def _local(store, run, timeout):
    folder = store.run_dir(run["id"])
    url = os.environ["SPECIMEN_LOCAL_VLM_URL"].rstrip("/") + "/chat/completions"
    schema = json.loads((folder / "schema.json").read_text())
    body = {"model": run["model"], "max_tokens": 6000,
            "messages": [{"role": "user", "content": [{"type": "text", "text": (folder / "prompt.txt").read_text()},
                                                       *image_blocks(store, run["image_ids"], "openai")]}],
            "response_format": {"type": "json_schema", "json_schema": {"name": "specimen_observation", "strict": True, "schema": schema}}}
    headers = {"Content-Type": "application/json"}
    if os.environ.get("SPECIMEN_LOCAL_VLM_API_KEY"):
        headers["Authorization"] = "Bearer " + os.environ["SPECIMEN_LOCAL_VLM_API_KEY"]
    with urlopen(Request(url, canonical(body).encode(), headers=headers), timeout=timeout) as response:
        response_raw = response.read(16_000_000)
    write_new(folder / "http-response.json", response_raw)
    output = json.loads(response_raw)
    choice = output["choices"][0]
    raw = choice["message"].get("content") or ""
    error = None if choice.get("finish_reason") == "stop" else "local response incomplete"
    return strip_fences(raw), error, {"usage": output.get("usage", {}), "model_reported": output.get("model")}


def strip_fences(raw: str) -> str:
    text = raw.strip()
    if text.startswith("```"):
        text = text.split("\n", 1)[1] if "\n" in text else ""
        if text.rstrip().endswith("```"):
            text = text.rstrip()[:-3]
    return text.strip()


def observe(store: Store, specimen_id: str, image_ids: list[str], provider_id: str = "claude", *,
            model: str | None = None, timeout: int = 300) -> dict:
    if provider_id not in PROVIDERS:
        raise ValueError(f"Unknown provider {provider_id!r}")
    model = model or PROVIDERS[provider_id]["model"] or os.environ.get("SPECIMEN_LOCAL_VLM_MODEL", "")
    run = begin_run(store, specimen_id, image_ids, provider_id, model)
    if not available(provider_id):
        return finish_run(store, run, "", error=f"provider {provider_id!r} is not available on this machine", state="unavailable")
    if provider_id == "dry-run":
        return finish_run(store, run, "", error="dry run: no model was called", state="dry_run")
    started = time.monotonic()
    raw, error, telemetry = "", None, {}
    try:
        if True:
            raw, error, telemetry = {"claude": _claude, "codex": _codex, "local": _local}[provider_id](store, run, timeout)
    except Exception as exc:  # keep the evidence trail even when the transport fails
        error = f"{type(exc).__name__}: {exc}"
    telemetry["wall_seconds"] = round(time.monotonic() - started, 3)
    return finish_run(store, run, raw, error=error, telemetry=telemetry)


def observe_all(store: Store, provider_id: str = "claude", *, specimens: list[str] | None = None,
                skip_usable: bool = True, timeout: int = 300, workers: int = 1, log=print) -> list[dict]:
    from concurrent.futures import ThreadPoolExecutor
    done = {r["specimen_id"] for r in store.runs() if r["terminal"].get("state") == "usable"}
    todo = []
    for specimen in store.specimens():
        if specimens and specimen["id"] not in specimens:
            continue
        if skip_usable and specimen["id"] in done:
            continue
        image_ids = [i["id"] for i in store.images(specimen["id"])]
        if image_ids:
            todo.append((specimen["id"], image_ids))
    log(f"{len(todo)} specimens to observe with {provider_id} ({len(done)} already usable), {workers} workers")

    def one(item):
        specimen_id, image_ids = item
        result = observe(store, specimen_id, image_ids, provider_id, timeout=timeout)
        state = result["terminal"]["state"]
        log(f"{specimen_id}: {state}" + (f" ({'; '.join(result['terminal']['errors'])[:200]})" if state != "usable" else ""))
        return result

    with ThreadPoolExecutor(max_workers=max(1, workers)) as pool:
        return list(pool.map(one, todo))


def revalidate(store: Store, log=print) -> dict:
    """Re-check failed runs' saved raw responses with the current normaliser.
    The original terminal record is untouched; a revalidation.json records the outcome."""
    counts = {"repaired": 0, "still_failed": 0, "skipped": 0}
    for run in store.runs():
        folder = store.run_dir(run["id"])
        if run["terminal"].get("state") != "failed" or (folder / "revalidation.json").exists():
            counts["skipped"] += 1
            continue
        raw = (folder / "raw-response.txt").read_text()
        try:
            payload = json.loads(raw)
        except ValueError:
            counts["still_failed"] += 1
            continue
        changes = normalise(payload)
        errors = validate(payload, run["image_ids"])
        record = {"finished": now(), "state": "usable" if not errors else "failed", "errors": errors,
                  "normalisations": changes, "original_errors": run["terminal"].get("errors", []),
                  "note": "validated again from the saved raw response with the current normaliser; no new model call"}
        if not errors:
            write_new(folder / "result.json", (canonical(payload) + "\n").encode())
            write_new(folder / "revalidation.json", (canonical(record) + "\n").encode())
            counts["repaired"] += 1
            log(f"{run['specimen_id']}: repaired ({len(changes)} normalisations)")
        else:
            counts["still_failed"] += 1
    return counts
