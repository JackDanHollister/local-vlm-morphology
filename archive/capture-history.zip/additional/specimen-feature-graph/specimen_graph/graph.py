"""Assemble the specimen graph from store records, features and locations."""

from __future__ import annotations

import math

import networkx as nx
import numpy as np

from . import features as feat
from .contract import FEATURES
from .locations import haversine_km
from .store import digest

DEFAULT_CONFIG = {
    "knn_k": 3,                  # similarity neighbours per specimen
    "knn_mode": "union",         # union: either side's neighbour; mutual: both sides
    "similarity_min": 0.0,       # cosine similarity floor for kNN edges
    "family_weights": {"shape": 1.0, "colour": 1.0, "texture": 1.0, "colour_vocab": 1.0},
    "privacy": {"coordinate_decimals": None, "drop_extra": False},
    "near_km": 25.0,             # geographic proximity edge radius
    "grid_degrees": 1.0,         # region cell size
    "hash_hamming_max": 4,       # near-duplicate: both pHash and dHash Hamming distance at or under this
    "colour_min_fraction": 0.08,  # minimum share to link a colour node
    "colour_top_n": 3,           # link at most this many measured colours per specimen
    "elongation_bins": [1.6, 2.6],  # compact | elongate | very elongate
}


def elongation_class(value) -> str | None:
    if value is None:
        return None
    lo, hi = DEFAULT_CONFIG["elongation_bins"]
    return "compact" if value < lo else "elongate" if value < hi else "very elongate"


def zscore(matrix: np.ndarray) -> np.ndarray:
    with np.errstate(all="ignore"):
        mean = np.nanmean(matrix, axis=0)
        std = np.nanstd(matrix, axis=0)
    std = np.where((std == 0) | np.isnan(std), 1.0, std)
    z = (matrix - mean) / std
    return np.where(np.isnan(z), 0.0, z)


def cosine_matrix(z: np.ndarray) -> np.ndarray:
    norms = np.linalg.norm(z, axis=1, keepdims=True)
    unit = z / np.where(norms == 0, 1.0, norms)
    return unit @ unit.T


def edge_id(source, target, label) -> str:
    return "edge:" + digest([source, target, label])[:24]


def family_weight_vector(cfg: dict) -> np.ndarray:
    fw = cfg["family_weights"]
    weights = [fw["shape"]] * len(feat.SHAPE_NAMES) + [fw["colour"]] * len(feat.COLOUR_NAMES) + \
              [fw["texture"]] * len(feat.TEXTURE_NAMES) + [fw["colour_vocab"]] * len(feat.COLOUR_VOCABULARY)
    return np.sqrt(np.array(weights, dtype=float))


def build(snapshot: dict, locations: dict | None = None, config: dict | None = None, ranges: dict | None = None) -> nx.MultiDiGraph:
    cfg = {**DEFAULT_CONFIG, **(config or {})}
    loc_records = (locations or {}).get("records", {})
    G = nx.MultiDiGraph(schema="specimen-feature-graph-v1", config=cfg)

    def node(key, label, kind, **data):
        G.add_node(key, label=label, kind=kind, **data)

    def edge(source, target, label, layer="evidence", **data):
        G.add_edge(source, target, key=edge_id(source, target, label), label=label, layer=layer, **data)

    def pair_edge(a, b, label, **data):
        """One canonical analysis edge per unordered specimen pair."""
        a, b = sorted([a, b])
        key = edge_id(a, b, label)
        if not G.has_edge(a, b, key):
            G.add_edge(a, b, key=key, label=label, layer="analysis", **data)

    # specimens and images
    per_specimen_features: dict[str, list[dict]] = {}
    for s in snapshot["specimens"]:
        node("specimen:" + s["id"], s["label"], "specimen", record=s, species=s.get("extra", {}).get("species"))
        species = s.get("extra", {}).get("species")
        if species:
            node("species:" + species, species.replace("_", " "), "species", record={"species": species, "genus": s["extra"].get("genus")})
            edge("specimen:" + s["id"], "species:" + species, "belongs to species")
    for image in snapshot["images"]:
        node(image["id"], image["source_name"] or image["id"][-6:], "image", record=image)
        edge("specimen:" + image["specimen_id"], image["id"], "depicted in")
        f = snapshot["features"].get(image["id"])
        if f:
            per_specimen_features.setdefault(image["specimen_id"], []).append(f)
            G.nodes[image["id"]]["features"] = {"mask": f["mask"], "shape": f["shape"], "colour": {k: v for k, v in f["colour"].items() if k != "hsv_hist"},
                                                "texture": f["texture"], "hashes": f["hashes"]}

    # aggregated descriptors -> specimen node, colour and shape-class nodes
    specimen_ids = [s["id"] for s in snapshot["specimens"]]
    aggregates = {}
    for sid in specimen_ids:
        agg = feat.aggregate(per_specimen_features.get(sid, []))
        aggregates[sid] = agg
        G.nodes["specimen:" + sid]["descriptors"] = dict(zip(agg["vector_names"], agg["vector"]))
        G.nodes["specimen:" + sid]["image_count"] = agg["image_count"]
        ranked = sorted(agg["colours"].items(), key=lambda kv: -kv[1])[: cfg["colour_top_n"]]
        for rank, (colour, fraction) in enumerate(ranked, 1):
            if fraction >= cfg["colour_min_fraction"]:
                node("colour:" + colour, colour, "colour", record={"vocabulary": "specimen-features-v1 body.colours subset"})
                edge("specimen:" + sid, "colour:" + colour, "shows colour", weight=round(fraction, 4), rank=rank)
        cls = elongation_class(G.nodes["specimen:" + sid]["descriptors"].get("elongation"))
        if cls:
            node("shape:" + cls.replace(" ", "_"), cls, "shape_class", record={"bins": cfg["elongation_bins"], "descriptor": "elongation"})
            edge("specimen:" + sid, "shape:" + cls.replace(" ", "_"), "has shape class")

    # feature similarity (kNN on z-scored descriptor vectors)
    vectors = np.array([[np.nan if v is None else v for v in aggregates[s]["vector"]] for s in specimen_ids], dtype=float)
    if len(specimen_ids) >= 2 and np.isfinite(vectors).any():
        z = zscore(vectors) * family_weight_vector(cfg)
        sims = cosine_matrix(z)
        neighbours: dict[str, set[str]] = {}
        for i, a in enumerate(specimen_ids):
            if aggregates[a]["image_count"] == 0:
                continue
            order = [j for j in np.argsort(-sims[i]) if j != i and aggregates[specimen_ids[j]]["image_count"] > 0]
            neighbours[a] = {specimen_ids[j] for j in order[: cfg["knn_k"]] if sims[i, j] >= cfg["similarity_min"]}
        for a, nbrs in neighbours.items():
            for b in nbrs:
                if cfg["knn_mode"] == "mutual" and a not in neighbours.get(b, set()):
                    continue
                pair_edge("specimen:" + a, "specimen:" + b, "similar to",
                          weight=round(float(sims[specimen_ids.index(a), specimen_ids.index(b)]), 4),
                          basis="cosine of weighted z-scored model-free descriptors; hypothesis-generating only")

    # near duplicates on perceptual hash across different specimens
    images = [i for i in snapshot["images"] if i["id"] in snapshot["features"]]
    for x in range(len(images)):
        for y in range(x + 1, len(images)):
            a, b = images[x], images[y]
            if a["specimen_id"] == b["specimen_id"]:
                continue
            ha, hb = snapshot["features"][a["id"]]["hashes"], snapshot["features"][b["id"]]["hashes"]
            dp, dd = feat.hamming(ha["phash"], hb["phash"]), feat.hamming(ha["dhash"], hb["dhash"])
            if max(dp, dd) <= cfg["hash_hamming_max"]:
                pair_edge(a["id"], b["id"], "near duplicate", weight=max(dp, dd), phash_distance=dp, dhash_distance=dd,
                          basis="pHash and dHash Hamming distances; threshold is configuration, not a biological claim")

    # observations from usable model runs
    for run in snapshot["runs"]:
        if run["terminal"].get("state") != "usable" or not run.get("result"):
            continue
        node(run["id"], f"{run['provider']}:{run['model']}", "model_run", record={k: v for k, v in run.items() if k not in {"result", "images"}})
        for o in run["result"]["observations"]:
            key = run["id"] + ":" + o["feature_id"]
            f_id = "feature:" + o["feature_id"]
            node(f_id, FEATURES[o["feature_id"]]["label"], "feature", record=FEATURES[o["feature_id"]])
            value = "unknown" if o["status"] == "unknown" else "not applicable" if o["status"] == "not_applicable" else str(o["value"])
            node(key, value, "observation", record=o)
            edge("specimen:" + run["specimen_id"], key, "has observation")
            edge(key, f_id, "measures")
            if o["status"] == "observed" and not isinstance(o["value"], list):
                t_id = f"trait:{o['feature_id']}={o['value']}"
                node(t_id, f"{FEATURES[o['feature_id']]['label']} = {o['value']}", "trait_value",
                     record={"feature_id": o["feature_id"], "value": o["value"], "vocabulary": FEATURES[o["feature_id"]]})
                edge("specimen:" + run["specimen_id"], t_id, "has trait", run_id=run["id"], visibility=o["visibility"], confidence=o["confidence"])
                edge(t_id, f_id, "value of")
            edge(key, run["id"], "generated by")
            for image_id in sorted({e["image_id"] for e in o["evidence"]}):
                if image_id in G:
                    edge(key, image_id, "supported by")
            if o["feature_id"] == "body.colours" and o["status"] == "observed":
                for colour in o["value"]:
                    node("colour:" + colour, colour, "colour", record={"vocabulary": "specimen-features-v1 body.colours"})
                    edge(key, "colour:" + colour, "names colour")
            if o["feature_id"] in {"body.primary_colour", "body.secondary_colour", "body.tertiary_colour"} and o["status"] == "observed" and o["value"] != "other":
                node("colour:" + o["value"], o["value"], "colour", record={"vocabulary": "specimen-features-v1 body.colours"})
                edge("specimen:" + run["specimen_id"], "colour:" + o["value"], "observed colour",
                     rank={"body.primary_colour": 1, "body.secondary_colour": 2, "body.tertiary_colour": 3}[o["feature_id"]], run_id=run["id"])

    # locations, sites, regions
    located = []
    for sid in specimen_ids:
        rec = loc_records.get(sid)
        if not rec:
            continue
        located.append(sid)
        lid = rec["location_id"]
        lat, lon = rec["latitude"], rec["longitude"]
        decimals = cfg["privacy"]["coordinate_decimals"]
        if decimals is not None:
            lat, lon = round(lat, decimals), round(lon, decimals)
        record = {k: v for k, v in rec.items() if k not in {"specimen_id", "source_line"}}
        record.update(latitude=lat, longitude=lon)
        if cfg["privacy"]["drop_extra"] or decimals is not None:
            record.pop("extra", None)
            record.pop("raw", None)
        node(lid, rec["locality"] or f"{lat:.4f}, {lon:.4f}", "location", record=record, latitude=lat, longitude=lon)
        edge("specimen:" + sid, lid, "collected at", **({"date": rec["collected_date"]} if rec["collected_date"] else {}))
        if rec["site_id"]:
            node("site:" + rec["site_id"], rec["site_id"], "site", record={"site_id": rec["site_id"]})
            edge(lid, "site:" + rec["site_id"], "within")
        cell = "region:cell:" + rec["grid_cell"].replace(",", "_")
        node(cell, f"{rec['grid_degrees']:g}° cell {rec['grid_cell']}", "region", record={"kind": "grid_cell", "cell": rec["grid_cell"], "degrees": rec["grid_degrees"]})
        edge(lid, cell, "within")
        if rec["country"]:
            cid = "region:country:" + rec["country"].lower().replace(" ", "_")
            node(cid, rec["country"], "region", record={"kind": "country", "name": rec["country"]})
            edge(cell, cid, "within")
    if ranges:
        size = ranges.get("cell_degrees", 0.5)
        for species, info in ranges.get("species", {}).items():
            sp_id = "species:" + species
            if sp_id not in G:
                continue
            G.nodes[sp_id]["record"].update(gbif=info.get("gbif"), occurrences=info.get("occurrences"), range_cells=len(info.get("cells", [])))
            G.nodes[sp_id]["range_cells"] = info.get("cells", [])
            G.nodes[sp_id]["range_points"] = info.get("sample_points", [])[:150]
            for c in info.get("cells", []):
                cid = "range:" + c.replace(",", "_")
                node(cid, f"{size:g}° range cell {c}", "range_cell", record={"cell": c, "degrees": size, "source": ranges.get("source")})
                edge(sp_id, cid, "ranges over")
    for i in range(len(located)):
        for j in range(i + 1, len(located)):
            a, b = loc_records[located[i]], loc_records[located[j]]
            km = haversine_km(a["latitude"], a["longitude"], b["latitude"], b["longitude"])
            if km <= cfg["near_km"]:
                pair_edge("specimen:" + located[i], "specimen:" + located[j], "near", weight=round(km, 3))
    G.graph["specimen_order"] = specimen_ids
    G.graph["located"] = located
    G.graph["descriptor_names"] = feat.VECTOR_NAMES
    return G


def specimen_projection(G: nx.MultiDiGraph, labels=("similar to", "near")) -> nx.Graph:
    """Undirected weighted specimen-only graph (analysis layer) for communities and stats.

    ``near`` edges are weighted 1/(1+km); ``similar to`` edges keep cosine similarity.
    Specimens without any analysis edge remain as isolates."""
    P = nx.Graph()
    for n, data in G.nodes(data=True):
        if data["kind"] == "specimen":
            P.add_node(n, **data)
    for u, v, data in G.edges(data=True):
        if data["label"] in labels and u in P and v in P:
            w = data.get("weight", 1.0)
            if data["label"] == "near":
                w = 1.0 / (1.0 + (w or 0.0))
            if P.has_edge(u, v):
                P[u][v]["weight"] += w
                P[u][v]["labels"].add(data["label"])
            else:
                P.add_edge(u, v, weight=w, labels={data["label"]})
    for u, v in P.edges:
        P[u][v]["labels"] = sorted(P[u][v]["labels"])
    return P
