"""Synthetic specimen images and a matching location CSV for end-to-end tests.

Deliberately includes awkward cases: label cards, pins, scale bars, gradient
backgrounds, a second view, a specimen with no location, a duplicate image
under a second specimen ID, and a near-empty frame that forces mask fallback.
"""

from __future__ import annotations

import csv
import math
import random
import shutil
from pathlib import Path

from PIL import Image, ImageDraw, ImageFilter

SITES = {  # colour family per site so features and geography covary in the demo
    "KENT": {"lat": 51.27, "lon": 0.52, "locality": "Blean Woods, Kent", "country": "United Kingdom", "colours": [(110, 65, 25), (140, 90, 40), (80, 45, 20)]},
    "CAIRN": {"lat": 57.08, "lon": -3.67, "locality": "Cairngorms, Aviemore", "country": "United Kingdom", "colours": [(40, 40, 45), (25, 25, 30), (60, 60, 70)]},
    "CORN": {"lat": 50.07, "lon": -5.70, "locality": "Land's End, Cornwall", "country": "United Kingdom", "colours": [(40, 130, 60), (30, 80, 170), (120, 40, 150)]},
    "NORM": {"lat": 49.18, "lon": -0.37, "locality": "Caen, Normandy", "country": "France", "colours": [(230, 190, 40), (240, 130, 30), (200, 40, 40)]},
}


def _rotate(points, cx, cy, deg):
    a = math.radians(deg)
    return [(cx + (x - cx) * math.cos(a) - (y - cy) * math.sin(a), cy + (x - cx) * math.sin(a) + (y - cy) * math.cos(a)) for x, y in points]


def draw_specimen(size, body_rgb, pattern, rng, *, angle=0.0, wings=False, label=False, pin=True, scale_bar=False, gradient=False):
    w, h = size
    base = 225 + rng.randint(-8, 8)
    img = Image.new("RGB", size, (base, base, base - 4))
    if gradient:
        px = img.load()
        for y in range(h):
            shade = int(30 * y / h)
            for x in range(0, w, 1):
                r, g, b = px[x, y]
                px[x, y] = (max(0, r - shade), max(0, g - shade), max(0, b - shade))
    d = ImageDraw.Draw(img)
    cx, cy = w / 2 + rng.randint(-30, 30), h / 2 + rng.randint(-20, 20)
    length, width = rng.randint(140, 220), rng.randint(50, 90)
    darker = tuple(max(0, c - 50) for c in body_rgb)
    # legs and antennae first so the body overlaps them
    for side in (-1, 1):
        for i, frac in enumerate((-0.3, 0.0, 0.3)):
            x0, y0 = cx + frac * length, cy
            x1, y1 = x0 + side * (width * 0.9), y0 + (i - 1) * 25 + side * 10
            x2, y2 = x1 + side * 25, y1 + 35
            pts = _rotate([(x0, y0), (x1, y1), (x2, y2)], cx, cy, angle)
            d.line(pts, fill=darker, width=4)
        ax, ay = cx + length * 0.55, cy + side * 8
        pts = _rotate([(ax, ay), (ax + 45, ay + side * 40)], cx, cy, angle)
        d.line(pts, fill=darker, width=3)
    if wings:
        for side in (-1, 1):
            wing = _rotate([(cx - length * 0.2, cy), (cx - length * 0.6, cy + side * width * 1.3), (cx + length * 0.05, cy + side * width * 0.7)], cx, cy, angle)
            d.polygon(wing, fill=tuple(min(255, c + 70) for c in body_rgb), outline=darker)
    # body as a rotated polygon approximating an ellipse
    pts = _rotate([(cx + length / 2 * math.cos(t), cy + width / 2 * math.sin(t)) for t in [i / 40 * 2 * math.pi for i in range(40)]], cx, cy, angle)
    d.polygon(pts, fill=body_rgb, outline=darker)
    head = _rotate([(cx + length * 0.5, cy)], cx, cy, angle)[0]
    d.ellipse([head[0] - 22, head[1] - 22, head[0] + 22, head[1] + 22], fill=darker)
    eye = _rotate([(cx + length * 0.58, cy - 10), (cx + length * 0.58, cy + 10)], cx, cy, angle)
    for ex, ey in eye:
        d.ellipse([ex - 4, ey - 4, ex + 4, ey + 4], fill=(10, 10, 10))
    if pattern == "spotted":
        for _ in range(rng.randint(6, 12)):
            t = rng.uniform(0, 2 * math.pi)
            r = rng.uniform(0.2, 0.8)
            sx, sy = _rotate([(cx + r * length / 2 * math.cos(t), cy + r * width / 2 * math.sin(t))], cx, cy, angle)[0]
            d.ellipse([sx - 7, sy - 7, sx + 7, sy + 7], fill=(245, 240, 220))
    elif pattern == "striped":
        for k in range(-3, 4):
            fx = cx + k * length / 8
            pts = _rotate([(fx, cy - width / 2 * math.sqrt(max(0, 1 - (k / 4) ** 2))), (fx, cy + width / 2 * math.sqrt(max(0, 1 - (k / 4) ** 2)))], cx, cy, angle)
            d.line(pts, fill=(20, 20, 20), width=5)
    if pin:
        px_, py_ = _rotate([(cx + length * 0.15, cy)], cx, cy, angle)[0]
        d.line([(px_, py_ - 5), (px_, py_ - 140)], fill=(60, 60, 60), width=3)
        d.ellipse([px_ - 5, py_ - 150, px_ + 5, py_ - 140], fill=(30, 30, 30))
    if label:
        d.rectangle([20, h - 110, 250, h - 20], fill=(250, 248, 235), outline=(120, 110, 90))
        d.text((32, h - 100), "NHM demo label\nColl. J. Hollister\nsynthetic 2026", fill=(40, 40, 40))
    if scale_bar:
        d.rectangle([w - 150, h - 40, w - 30, h - 30], fill=(0, 0, 0))
        d.text((w - 150, h - 60), "10 mm", fill=(0, 0, 0))
    return img.filter(ImageFilter.GaussianBlur(0.6))


def generate(out_dir, n: int = 12, seed: int = 7) -> dict:
    rng = random.Random(seed)
    out_dir = Path(out_dir)
    images_dir = out_dir / "images"
    if images_dir.exists():
        shutil.rmtree(images_dir)
    images_dir.mkdir(parents=True)
    site_ids = list(SITES)
    rows = []
    files = []
    for i in range(n):
        sid = f"demo{i+1:02d}"
        site = SITES[site_ids[i % len(site_ids)]]
        colour = rng.choice(site["colours"])
        pattern = rng.choice(["uniform", "spotted", "striped"])
        img = draw_specimen((900, 700), colour, pattern, rng, angle=rng.uniform(-25, 25), wings=rng.random() < 0.4,
                            label=i % 3 == 0, pin=i % 4 != 1, scale_bar=i % 5 == 0, gradient=i % 4 == 2)
        path = images_dir / (f"{sid}__dorsal.jpg" if i % 3 == 0 else f"{sid}.jpg")
        img.save(path, quality=92)
        files.append(path)
        if i % 3 == 0:  # second view for some specimens
            img2 = draw_specimen((700, 900), colour, pattern, rng, angle=rng.uniform(60, 120), wings=rng.random() < 0.4, label=False, pin=True)
            p2 = images_dir / f"{sid}__lateral.jpg"
            img2.save(p2, quality=88)
            files.append(p2)
        if i != n - 1:  # last specimen deliberately has no location row
            jitter = lambda: rng.uniform(-0.05, 0.05)
            rows.append({"specimen_id": sid, "latitude": round(site["lat"] + jitter(), 5), "longitude": round(site["lon"] + jitter(), 5),
                         "locality": site["locality"], "country": site["country"],
                         "collected_date": f"2026-0{rng.randint(5, 9)}-{rng.randint(1, 28):02d}", "site_id": site_ids[i % len(site_ids)]})
    # duplicate image under another specimen id, and a near-empty frame
    dup_src = files[1]
    dup = images_dir / "demo_dup.jpg"
    shutil.copyfile(dup_src, dup)
    files.append(dup)
    empty = Image.new("RGB", (800, 600), (228, 228, 224))
    ImageDraw.Draw(empty).ellipse([400, 300, 404, 304], fill=(90, 60, 30))
    empty_path = images_dir / "demo_empty.jpg"
    empty.save(empty_path, quality=90)
    files.append(empty_path)
    rows.append({"specimen_id": "demo_dup", "latitude": 51.5, "longitude": -0.12, "locality": "London", "country": "United Kingdom", "collected_date": "12/06/2026", "site_id": ""})
    rows.append({"specimen_id": "demo_bad", "latitude": "not-a-number", "longitude": 0, "locality": "bad row", "country": "", "collected_date": "", "site_id": ""})
    csv_path = out_dir / "locations.csv"
    with open(csv_path, "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=["specimen_id", "latitude", "longitude", "locality", "country", "collected_date", "site_id"])
        w.writeheader()
        w.writerows(rows)
    return {"images": [str(f) for f in files], "locations": str(csv_path), "specimens": n + 2}
