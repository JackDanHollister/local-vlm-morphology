"""Graph exports: graph JSON (openscan-compatible), JSON-LD, GraphML, GEXF, CSV,
an undirected specimen projection, and a self-contained offline HTML viewer.

Flattening policy for GraphML/GEXF: scalar attributes pass through, ``None``
is dropped, anything else (dicts, lists) is serialised as a JSON string.
Multi-edges keep their canonical ``edge:`` keys.
"""

from __future__ import annotations

import csv
import json
from pathlib import Path

import networkx as nx

from .store import canonical

NODE_FIELDS = ("id", "label", "kind")
EDGE_FIELDS = ("id", "source", "target", "label")


def graph_json(G: nx.MultiDiGraph) -> dict:
    nodes = [{"id": n, **{k: v for k, v in d.items()}} for n, d in G.nodes(data=True)]
    edges = [{"id": k, "source": u, "target": v, **d} for u, v, k, d in G.edges(keys=True, data=True)]
    meta = {k: v for k, v in G.graph.items() if k not in {"specimen_order", "located"}}
    return {"schema": G.graph.get("schema", "specimen-feature-graph-v1"), "meta": meta, "nodes": nodes, "edges": edges}


def projection_json(P: nx.Graph) -> dict:
    return {"schema": "specimen-projection-v1",
            "nodes": [{"id": n, "label": d["label"], "kind": d["kind"]} for n, d in P.nodes(data=True)],
            "edges": [{"source": u, "target": v, **d} for u, v, d in P.edges(data=True)]}


def jsonld(G: nx.MultiDiGraph) -> dict:
    g = graph_json(G)
    return {"@context": {"@version": 1.1, "lab": "urn:specimen-graph:", "prov": "http://www.w3.org/ns/prov#",
                         "record": {"@id": "lab:record", "@type": "@json"}},
            "@graph": [{"@id": "urn:specimen-graph:" + n["id"], "@type": "lab:" + n["kind"], "lab:label": n["label"],
                        "record": n.get("record", {})} for n in g["nodes"]] +
                      [{"@id": "urn:specimen-graph:" + e["source"], "lab:" + e["label"].replace(" ", "_"): {"@id": "urn:specimen-graph:" + e["target"]}}
                       for e in g["edges"]]}


def flatten(attrs: dict) -> dict:
    out = {}
    for k, v in attrs.items():
        if v is None:
            continue
        if isinstance(v, (str, int, float, bool)):
            out[k] = v
        else:
            out[k] = json.dumps(v, sort_keys=True, ensure_ascii=False)
    return out


def flat_copy(G: nx.MultiDiGraph) -> nx.MultiDiGraph:
    H = nx.MultiDiGraph()
    H.graph.update(flatten(G.graph))
    for n, d in G.nodes(data=True):
        H.add_node(n, **flatten(d))
    for u, v, k, d in G.edges(keys=True, data=True):
        H.add_edge(u, v, key=k, **flatten(d))
    return H


def write_csv(G: nx.MultiDiGraph, out_dir: Path) -> None:
    g = graph_json(G)
    with open(out_dir / "nodes.csv", "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["id", "label", "kind", "image_count", "latitude", "longitude", "record_json"])
        for n in g["nodes"]:
            w.writerow([n["id"], n["label"], n["kind"], n.get("image_count", ""), n.get("latitude", ""), n.get("longitude", ""),
                        json.dumps(n.get("record", {}), ensure_ascii=False)])
    with open(out_dir / "edges.csv", "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["id", "source", "target", "label", "layer", "weight"])
        for e in g["edges"]:
            w.writerow([e["id"], e["source"], e["target"], e["label"], e.get("layer", ""), e.get("weight", "")])
    names = G.graph.get("descriptor_names", [])
    with open(out_dir / "specimen_descriptors.csv", "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["specimen_id", "image_count", *names])
        for n in g["nodes"]:
            if n["kind"] == "specimen":
                desc = n.get("descriptors", {})
                w.writerow([n["id"].split(":", 1)[1], n.get("image_count", 0), *["" if desc.get(x) is None else desc.get(x) for x in names]])


def thumbnails(G: nx.MultiDiGraph, store, size: int = 110) -> dict[str, str]:
    """First image per specimen as a small JPEG data URI for the viewer."""
    import base64
    import io
    from PIL import Image, ImageOps
    thumbs = {}
    if store is None:
        return thumbs
    for u, v, d in G.edges(data=True):
        if d["label"] != "depicted in" or u in thumbs:
            continue
        try:
            with Image.open(store.image_path(v)) as im:
                im = ImageOps.exif_transpose(im).convert("RGB")
                im.thumbnail((size, size))
                buf = io.BytesIO()
                im.save(buf, "JPEG", quality=70)
            thumbs[u] = "data:image/jpeg;base64," + base64.b64encode(buf.getvalue()).decode()
        except (OSError, ValueError):
            continue
    return thumbs


def write_all(G: nx.MultiDiGraph, P: nx.Graph, out_dir, summary: dict | None = None, metadata: dict | None = None,
              *, store=None, geo: dict | None = None, ranges: dict | None = None) -> dict[str, str]:
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    g = graph_json(G)
    files = {}
    (out_dir / "graph.json").write_text(canonical(g) + "\n")
    (out_dir / "graph.jsonld").write_text(canonical(jsonld(G)) + "\n")
    (out_dir / "specimen_projection.json").write_text(canonical(projection_json(P)) + "\n")
    H = flat_copy(G)
    nx.write_graphml(H, out_dir / "graph.graphml")
    nx.write_gexf(H, out_dir / "graph.gexf")
    write_csv(G, out_dir)
    if summary is not None:
        (out_dir / "report.json").write_text(json.dumps(summary, indent=1, sort_keys=True) + "\n")
    if metadata is not None:
        (out_dir / "run_metadata.json").write_text(json.dumps(metadata, indent=1, sort_keys=True) + "\n")
    (out_dir / "viewer.html").write_text(viewer_html(g, projection_json(P), summary or {}, geo=geo, thumbs=thumbnails(G, store)))
    for p in sorted(out_dir.iterdir()):
        files[p.name] = str(p)
    return files


VIEWER_TEMPLATE = r"""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><title>Specimen feature graph</title>
<style>
:root{--bg:#f7f7f5;--fg:#1c1c1c;--panel:#fff;--line:#d9d9d4;--muted:#6b6b66;--hi:#c0392b}
*{box-sizing:border-box}body{margin:0;font:13px/1.4 system-ui,-apple-system,Segoe UI,sans-serif;background:var(--bg);color:var(--fg);display:grid;grid-template-columns:270px 1fr 400px;grid-template-rows:100vh;height:100vh}
aside,section{overflow:auto;padding:12px;background:var(--panel)}aside{border-right:1px solid var(--line)}
#right{border-left:1px solid var(--line);display:flex;flex-direction:column;padding:0}
#mapwrap{flex:0 0 46%;border-bottom:1px solid var(--line);position:relative;background:#eef3f6}#map{width:100%;height:100%;display:block}
#detail{flex:1;overflow:auto;padding:12px}
h1{font-size:15px;margin:0 0 8px}h2{font-size:12px;margin:12px 0 4px;color:var(--muted);text-transform:uppercase;letter-spacing:.04em}
label.kind{display:flex;align-items:center;gap:6px;margin:2px 0;cursor:pointer}label.kind i{width:10px;height:10px;border-radius:50%;display:inline-block;flex:none}
canvas{display:block;width:100%;height:100%;background:var(--bg);cursor:grab}
main{position:relative}#hint{position:absolute;left:10px;bottom:8px;color:var(--muted);font-size:12px;pointer-events:none}
input[type=search],select{width:100%;padding:5px;border:1px solid var(--line);border-radius:4px;font:inherit;background:#fff}
pre{white-space:pre-wrap;word-break:break-word;font-size:11px;background:#f2f2ef;padding:8px;border-radius:4px;max-height:40vh;overflow:auto}
button{font:inherit;padding:4px 8px;border:1px solid var(--line);background:#fff;border-radius:4px;cursor:pointer}button.on{background:var(--hi);color:#fff;border-color:var(--hi)}
.chips{display:flex;flex-wrap:wrap;gap:4px}.chips button{padding:2px 7px;font-size:12px}
.stat{display:flex;justify-content:space-between;color:var(--muted)}.muted{color:var(--muted)}
ul.nb{padding-left:16px;margin:4px 0;max-height:22vh;overflow:auto}ul.nb li{cursor:pointer}ul.nb li:hover{text-decoration:underline}
.strip{display:flex;flex-wrap:wrap;gap:4px;margin:6px 0}.strip img{height:52px;border:2px solid transparent;border-radius:3px;cursor:pointer}.strip img.sel{border-color:var(--hi)}
#maplegend{position:absolute;left:8px;bottom:6px;font-size:11px;color:var(--muted);background:rgba(255,255,255,.8);padding:3px 6px;border-radius:3px}
</style></head><body>
<aside>
<h1>Specimen feature graph</h1>
<div class="stat"><span>nodes</span><b id="ncount"></b></div><div class="stat"><span>edges</span><b id="ecount"></b></div><div class="stat"><span>highlighted specimens</span><b id="hcount">0</b></div>
<h2>Search</h2><input type="search" id="search" placeholder="label or id">
<h2>Filter: colour</h2><div class="chips" id="colours"></div>
<h2>Filter: trait</h2><select id="trait"><option value="">any trait value</option></select>
<h2>Filter: species</h2><select id="species"><option value="">all species</option></select>
<div style="margin-top:6px"><button id="clear">Clear filters</button> <label class="kind" style="display:inline-flex"><input type="checkbox" id="andmode"> match all</label></div>
<h2>Node kinds</h2><div id="kinds"></div>
<h2>Edge layers</h2><label class="kind"><input type="checkbox" id="evidence" checked> evidence</label><label class="kind"><input type="checkbox" id="analysis"> analysis (similar / near / duplicate)</label>
<h2>Layout</h2><button id="reheat">Re-run layout</button> <button id="fit">Fit</button>
<p class="muted" id="capnote"></p>
<h2>Report</h2><div id="report" class="muted"></div>
</aside>
<main><canvas id="c"></canvas><div id="hint">drag nodes · wheel zoom · drag background to pan · click a node for its record · map points and graph stay linked</div></main>
<section id="right"><div id="mapwrap"><svg id="map"></svg><div id="maplegend">simulated specimen localities (GBIF range draws) · squares = species range cells</div></div><div id="detail"><h2>Selected</h2><div id="sel" class="muted">Nothing selected. Use a colour or trait filter, or click a node or map point.</div></div></section>
<script id="data" type="application/json">__DATA__</script>
<script>
const data=JSON.parse(document.getElementById('data').textContent);
const graph=data.graph, summary=data.summary, geo=data.geo, thumbs=data.thumbs;
const COLOURS={specimen:'#c0392b',species:'#6c3483',image:'#7f8c8d',feature:'#8e44ad',observation:'#b39ddb',trait_value:'#5b2c6f',colour:'#f39c12',shape_class:'#d35400',location:'#27ae60',site:'#16a085',region:'#1abc9c',range_cell:'#a9dfbf',model_run:'#2c3e50'};
const SWATCH={black:'#111',brown:'#7a4a1f',grey:'#8a8a8a',white:'#f4f4f4',yellow:'#e6c519',orange:'#ef8a1c',red:'#c62828',green:'#3a9a4a',blue:'#2f5fd0',purple:'#8e44ad',metallic:'#9fb7c9',other:'#c9c9c9'};
const RADIUS={specimen:7,species:9,location:5,region:7,site:6,colour:8,shape_class:6,feature:6,trait_value:5,observation:3,image:3,model_run:5,range_cell:3};
const nodes=graph.nodes.map(n=>({...n,x:0,y:0,vx:0,vy:0}));const byId=new Map(nodes.map(n=>[n.id,n]));
const edges=graph.edges.filter(e=>byId.has(e.source)&&byId.has(e.target));
const adj=new Map();for(const e of edges){(adj.get(e.source)||adj.set(e.source,[]).get(e.source)).push(e);(adj.get(e.target)||adj.set(e.target,[]).get(e.target)).push(e);}
const kinds=[...new Set(nodes.map(n=>n.kind))].sort();
const hidden=new Set(['image','observation','range_cell','model_run','feature','location','site','region']);
if(nodes.length>1500){hidden.add('trait_value');}
document.getElementById('capnote').textContent=`Image, location, site and region nodes start hidden (locations live on the map). Observation, model-run, feature and range-cell nodes are only in graph.json.`;
document.getElementById('ncount').textContent=nodes.length;document.getElementById('ecount').textContent=edges.length;
// specimen helpers
const specimens=nodes.filter(n=>n.kind==='specimen');
const specLoc=new Map();for(const e of edges)if(e.label==='collected at')specLoc.set(e.source,byId.get(e.target));
const specSpecies=new Map();for(const e of edges)if(e.label==='belongs to species')specSpecies.set(e.source,e.target);
const specColours=new Map();for(const e of edges)if(e.label==='shows colour'||e.label==='observed colour'){(specColours.get(e.source)||specColours.set(e.source,new Set()).get(e.source)).add(e.target.split(':')[1]);}
const specTraits=new Map();for(const e of edges)if(e.label==='has trait'){(specTraits.get(e.source)||specTraits.set(e.source,new Set()).get(e.source)).add(e.target);}
// filters
const filt={colours:new Set(),trait:'',species:''};
const cbox=document.getElementById('colours');
for(const c of nodes.filter(n=>n.kind==='colour').map(n=>n.id.split(':')[1]).sort()){const b=document.createElement('button');b.textContent=c;b.style.borderLeft='10px solid '+(SWATCH[c]||'#ccc');b.onclick=()=>{filt.colours.has(c)?filt.colours.delete(c):filt.colours.add(c);b.classList.toggle('on');applyFilters();};cbox.append(b);}
const tsel=document.getElementById('trait');for(const t of nodes.filter(n=>n.kind==='trait_value').sort((a,b)=>a.label.localeCompare(b.label))){const o=document.createElement('option');o.value=t.id;o.textContent=t.label;tsel.append(o);}
tsel.onchange=()=>{filt.trait=tsel.value;applyFilters();};
const ssel=document.getElementById('species');for(const sp of nodes.filter(n=>n.kind==='species').sort((a,b)=>a.label.localeCompare(b.label))){const o=document.createElement('option');o.value=sp.id;o.textContent=sp.label;ssel.append(o);}
ssel.onchange=()=>{filt.species=ssel.value;applyFilters();};
document.getElementById('clear').onclick=()=>{filt.colours.clear();filt.trait='';filt.species='';tsel.value='';ssel.value='';for(const b of cbox.children)b.classList.remove('on');applyFilters();};
document.getElementById('andmode').onchange=applyFilters;
let highlighted=new Set();
function applyFilters(){highlighted=new Set();const and=document.getElementById('andmode').checked;const active=filt.colours.size||filt.trait||filt.species;
if(active){for(const s of specimens){const cs=specColours.get(s.id)||new Set();const colourOk=filt.colours.size?(and?[...filt.colours].every(c=>cs.has(c)):[...filt.colours].some(c=>cs.has(c))):true;const traitOk=filt.trait?(specTraits.get(s.id)||new Set()).has(filt.trait):true;const spOk=filt.species?specSpecies.get(s.id)===filt.species:true;if(colourOk&&traitOk&&spOk)highlighted.add(s.id);}}
document.getElementById('hcount').textContent=highlighted.size;drawMap();showMatches();alpha=Math.max(alpha,0.2);}
function showMatches(){if(!highlighted.size)return;const box=document.getElementById('sel');box.innerHTML='';const h=document.createElement('div');h.innerHTML=`<b>${highlighted.size} specimens match</b> <span class="muted">(${[...filt.colours].join(', ')}${filt.trait?' · '+byId.get(filt.trait).label:''}${filt.species?' · '+byId.get(filt.species).label:''})</span>`;box.append(h);
const bySp={};for(const id of highlighted){const sp=specSpecies.get(id)?byId.get(specSpecies.get(id)).label:'unknown species';(bySp[sp]=bySp[sp]||[]).push(id);}
for(const sp of Object.keys(bySp).sort()){const t=document.createElement('div');t.className='muted';t.textContent=`${sp} (${bySp[sp].length})`;box.append(t);const strip=document.createElement('div');strip.className='strip';for(const id of bySp[sp]){if(thumbs[id]){const img=document.createElement('img');img.src=thumbs[id];img.title=byId.get(id).label;img.onclick=()=>select(byId.get(id));strip.append(img);}else{const b=document.createElement('button');b.textContent=byId.get(id).label;b.onclick=()=>select(byId.get(id));strip.append(b);}}box.append(strip);}}
// report
const rep=document.getElementById('report');
if(summary&&summary.communities){rep.innerHTML=`<div>communities: ${summary.communities.length}</div>`+(summary.mantel&&summary.mantel.r!=null?`<div>Mantel r=${summary.mantel.r} p=${summary.mantel.p} (exploratory)</div>`:'')+(summary.location_problems&&summary.location_problems.length?`<div>location problems: ${summary.location_problems.length}</div>`:'');}
// kinds
const kindBox=document.getElementById('kinds');
for(const k of kinds){const l=document.createElement('label');l.className='kind';const c=document.createElement('input');c.type='checkbox';c.checked=!hidden.has(k);c.onchange=()=>{c.checked?hidden.delete(k):hidden.add(k);reheat();};const i=document.createElement('i');i.style.background=COLOURS[k]||'#999';l.append(c,i,document.createTextNode(`${k} (${nodes.filter(n=>n.kind===k).length})`));kindBox.append(l);}
// graph canvas
const canvas=document.getElementById('c'),ctx=canvas.getContext('2d');
let W,H,scale=nodes.length>1000?0.55:1,tx=0,ty=0,drag=null,pan=null,selected=null,alpha=1,moved=false;
function resize(){W=canvas.width=canvas.clientWidth*devicePixelRatio;H=canvas.height=canvas.clientHeight*devicePixelRatio;}window.addEventListener('resize',()=>{resize();drawMap();});resize();
function visibleNodes(){return nodes.filter(n=>!hidden.has(n.kind));}
function visibleEdges(){const showE=document.getElementById('evidence').checked,showA=document.getElementById('analysis').checked;return edges.filter(e=>!hidden.has(byId.get(e.source).kind)&&!hidden.has(byId.get(e.target).kind)&&((e.layer==='analysis')?showA:showE));}
(function init(){const specs=nodes.filter(n=>n.kind==='species');const anchors=specs.length?specs:specimens;const R=Math.max(300,Math.min(700,anchors.length*10));anchors.forEach((n,i)=>{const a=i/anchors.length*2*Math.PI;n.x=Math.cos(a)*R;n.y=Math.sin(a)*R;});
for(const n of nodes){if(anchors.includes(n))continue;const nb=(adj.get(n.id)||[]).map(e=>byId.get(e.source===n.id?e.target:e.source)).filter(m=>anchors.includes(m));if(nb.length){n.x=nb.reduce((s,m)=>s+m.x,0)/nb.length*0.85+(Math.random()-.5)*90;n.y=nb.reduce((s,m)=>s+m.y,0)/nb.length*0.85+(Math.random()-.5)*90;}else{n.x=(Math.random()-.5)*300;n.y=(Math.random()-.5)*300;}}})();
const degree=new Map();for(const e of edges){degree.set(e.source,(degree.get(e.source)||0)+1);degree.set(e.target,(degree.get(e.target)||0)+1);}
function step(){if(alpha<0.004)return;const vn=visibleNodes(),ve=visibleEdges();const k=alpha;const MAXV=18;
const cell=80,grid=new Map();for(const n of vn){const key=(Math.floor(n.x/cell))+','+(Math.floor(n.y/cell));(grid.get(key)||grid.set(key,[]).get(key)).push(n);}
for(const a of vn){const gx=Math.floor(a.x/cell),gy=Math.floor(a.y/cell);for(let dx=-1;dx<=1;dx++)for(let dy=-1;dy<=1;dy++){const bucket=grid.get((gx+dx)+','+(gy+dy));if(!bucket)continue;for(const b of bucket){if(b===a)continue;let ddx=a.x-b.x,ddy=a.y-b.y;let d2=ddx*ddx+ddy*ddy;if(d2>cell*cell)continue;if(d2<1){ddx=(Math.random()-.5);ddy=(Math.random()-.5);d2=1;}d2=Math.max(d2,64);const f=Math.min(6,700/d2)*k;const d=Math.sqrt(d2);a.vx+=ddx/d*f;a.vy+=ddy/d*f;}}}
for(const e of ve){const a=byId.get(e.source),b=byId.get(e.target);const dx=b.x-a.x,dy=b.y-a.y,d=Math.sqrt(dx*dx+dy*dy)+0.01;const target=e.layer==='analysis'?120:(e.label==='belongs to species'?40:90);const hub=Math.max(degree.get(a.id)||1,degree.get(b.id)||1);const damp=e.label==='belongs to species'?0.4:Math.sqrt(Math.max(1,hub/4));const f=Math.max(-8,Math.min(8,(d-target)*0.04*k/damp));a.vx+=dx/d*f;a.vy+=dy/d*f;b.vx-=dx/d*f;b.vy-=dy/d*f;}
for(const n of vn){n.vx-=n.x*0.0015*k;n.vy-=n.y*0.0015*k;const sp=Math.hypot(n.vx,n.vy);if(sp>MAXV){n.vx*=MAXV/sp;n.vy*=MAXV/sp;}if(drag!==n){n.x+=n.vx;n.y+=n.vy;}n.vx*=0.5;n.vy*=0.5;const lim=2500;n.x=Math.max(-lim,Math.min(lim,n.x));n.y=Math.max(-lim,Math.min(lim,n.y));}alpha*=0.992;}
function isHi(n){return highlighted.size&&highlighted.has(n.id);}
function draw(){ctx.setTransform(1,0,0,1,0,0);ctx.clearRect(0,0,W,H);ctx.setTransform(scale*devicePixelRatio,0,0,scale*devicePixelRatio,W/2+tx*devicePixelRatio,H/2+ty*devicePixelRatio);
const q=document.getElementById('search').value.trim().toLowerCase();const dim=highlighted.size>0;
for(const e of visibleEdges()){const a=byId.get(e.source),b=byId.get(e.target);const hot=dim&&(highlighted.has(a.id)||highlighted.has(b.id));ctx.strokeStyle=e.layer==='analysis'?(hot?'rgba(192,57,43,.7)':'rgba(192,57,43,'+(dim?.08:.35)+')'):(hot?'rgba(0,0,0,.35)':'rgba(0,0,0,'+(dim?.04:.12)+')');ctx.lineWidth=e.layer==='analysis'?1.4:0.8;ctx.beginPath();ctx.moveTo(a.x,a.y);ctx.lineTo(b.x,b.y);ctx.stroke();}
for(const n of visibleNodes()){const r=RADIUS[n.kind]||5;ctx.beginPath();ctx.arc(n.x,n.y,r,0,2*Math.PI);let fill=n.kind==='colour'?(SWATCH[n.label]||'#ccc'):(COLOURS[n.kind]||'#999');ctx.globalAlpha=dim&&n.kind==='specimen'&&!highlighted.has(n.id)?0.18:1;ctx.fillStyle=fill;ctx.fill();if(n.kind==='colour'){ctx.lineWidth=1;ctx.strokeStyle='#666';ctx.stroke();}
if(n===selected||isHi(n)||(q&&(n.label.toLowerCase().includes(q)||n.id.toLowerCase().includes(q)))){ctx.lineWidth=2.5;ctx.strokeStyle='#111';ctx.stroke();}
ctx.globalAlpha=1;if((scale>0.9&&['species','colour','shape_class','site','region'].includes(n.kind))||n===selected||(scale>1.8&&n.kind==='specimen')){ctx.fillStyle='#222';ctx.font='11px system-ui';ctx.fillText(n.label,n.x+r+2,n.y+4);}}}
function frame(){step();draw();requestAnimationFrame(frame);}frame();
function toWorld(ev){const rect=canvas.getBoundingClientRect();return {x:(ev.clientX-rect.left-rect.width/2-tx)/scale,y:(ev.clientY-rect.top-rect.height/2-ty)/scale};}
function hit(p){let best=null,bd=1e9;for(const n of visibleNodes()){const r=(RADIUS[n.kind]||5)+3;const d=Math.hypot(n.x-p.x,n.y-p.y);if(d<r/Math.min(scale,1)&&d<bd){best=n;bd=d;}}return best;}
canvas.addEventListener('mousedown',ev=>{const p=toWorld(ev);const n=hit(p);moved=false;if(n){drag=n;alpha=Math.max(alpha,0.15);}else pan={x:ev.clientX-tx,y:ev.clientY-ty};});
window.addEventListener('mousemove',ev=>{if(drag){const p=toWorld(ev);drag.x=p.x;drag.y=p.y;drag.vx=drag.vy=0;moved=true;}else if(pan){tx=ev.clientX-pan.x;ty=ev.clientY-pan.y;}});
window.addEventListener('mouseup',ev=>{if(drag&&!moved)select(drag);drag=null;pan=null;});
canvas.addEventListener('wheel',ev=>{ev.preventDefault();const f=Math.exp(-ev.deltaY*0.001);scale=Math.min(8,Math.max(0.08,scale*f));},{passive:false});
document.getElementById('search').addEventListener('input',()=>{});
document.getElementById('evidence').onchange=document.getElementById('analysis').onchange=()=>{alpha=Math.max(alpha,0.5);};
function reheat(){alpha=1;}document.getElementById('reheat').onclick=reheat;document.getElementById('fit').onclick=()=>{scale=1;tx=ty=0;};
function select(n){selected=n;const box=document.getElementById('sel');box.innerHTML='';const h=document.createElement('div');h.innerHTML=`<b>${n.label}</b><br><span class="muted">${n.kind} · ${n.id}</span>`;box.append(h);
if(thumbs[n.id]){const img=document.createElement('img');img.src=thumbs[n.id];img.style.cssText='max-width:100%;margin:6px 0;border-radius:4px';box.append(img);}
const nb=(adj.get(n.id)||[]).map(e=>({label:e.label,dir:e.source===n.id?'→':'←',other:byId.get(e.source===n.id?e.target:e.source),weight:e.weight,rank:e.rank}));
const ul=document.createElement('ul');ul.className='nb';for(const x of nb.sort((a,b)=>a.label.localeCompare(b.label))){const li=document.createElement('li');li.textContent=`${x.dir} ${x.label}${x.rank?' #'+x.rank:''}${x.weight!=null?' ('+x.weight+')':''}: ${x.other.label} [${x.other.kind}]`;li.onclick=()=>select(x.other);ul.append(li);}
const h2=document.createElement('h2');h2.textContent=`${nb.length} edges`;box.append(h2,ul);
if(n.kind==='species'){const b=document.createElement('button');b.textContent='Filter to this species';b.onclick=()=>{ssel.value=n.id;filt.species=n.id;applyFilters();};box.append(b);}
if(n.kind==='colour'){const b=document.createElement('button');b.textContent='Filter to this colour';b.onclick=()=>{filt.colours.add(n.label);for(const c of cbox.children)if(c.textContent===n.label)c.classList.add('on');applyFilters();};box.append(b);}
if(n.kind==='trait_value'){const b=document.createElement('button');b.textContent='Filter to this trait';b.onclick=()=>{tsel.value=n.id;filt.trait=n.id;applyFilters();};box.append(b);}
const rec={...n};for(const k of ['x','y','vx','vy','range_points','range_cells'])delete rec[k];const pre=document.createElement('pre');pre.textContent=JSON.stringify(rec,null,1);box.append(pre);drawMap();}
// map (offline, equirectangular with cos(54°) longitude scaling)
const svg=document.getElementById('map');const BB={lon0:-11,lon1:2.5,lat0:49.5,lat1:61};const KX=Math.cos(55*Math.PI/180);
function proj(lat,lon){const w=svg.clientWidth,h=svg.clientHeight;const sx=w/((BB.lon1-BB.lon0)*KX),sy=h/(BB.lat1-BB.lat0);const s=Math.min(sx,sy);const ox=(w-(BB.lon1-BB.lon0)*KX*s)/2,oy=(h-(BB.lat1-BB.lat0)*s)/2;return [ox+(lon-BB.lon0)*KX*s,oy+(BB.lat1-lat)*s];}
function el(t,a){const e=document.createElementNS('http://www.w3.org/2000/svg',t);for(const k in a)e.setAttribute(k,a[k]);return e;}
function drawMap(){svg.replaceChildren();if(!svg.clientWidth)return;
for(const c of geo)for(const ring of c.rings){svg.append(el('path',{d:ring.map((p,i)=>(i?'L':'M')+proj(p[1],p[0]).join(',')).join('')+'Z',fill:'#f7f4ec',stroke:'#b9b3a6','stroke-width':0.7}));}
// species range cells for the selected species / highlighted specimens' species
const spIds=new Set();if(selected&&selected.kind==='species')spIds.add(selected.id);if(selected&&selected.kind==='specimen'&&specSpecies.get(selected.id))spIds.add(specSpecies.get(selected.id));if(filt.species)spIds.add(filt.species);
if(spIds.size<=3)for(const id of spIds){const sp=byId.get(id);const deg=(sp.record&&sp.record.cell_degrees)||0.5;for(const c of (sp.range_cells||[])){const [la,lo]=c.split(',').map(Number);const [x0,y0]=proj(la+deg,lo),[x1,y1]=proj(la,lo+deg);svg.append(el('rect',{x:x0,y:y0,width:x1-x0,height:y1-y0,fill:'rgba(108,52,131,.18)',stroke:'rgba(108,52,131,.35)','stroke-width':0.4}));}}
const dim=highlighted.size>0;
for(const s of specimens){const loc=specLoc.get(s.id);if(!loc||loc.latitude==null)continue;const [x,y]=proj(loc.latitude,loc.longitude);const hi=highlighted.has(s.id),sel=selected===s;const c=el('circle',{cx:x,cy:y,r:sel?6:hi?4.5:3,fill:sel?'#111':hi?'#c0392b':'#27ae60','fill-opacity':dim&&!hi&&!sel?0.15:0.85,stroke:sel||hi?'#fff':'none','stroke-width':1,style:'cursor:pointer'});c.append(el('title',{}));c.firstChild.textContent=s.label+(loc.record&&loc.record.locality_basis?' · '+loc.record.locality_basis:'');c.addEventListener('click',()=>select(s));svg.append(c);}
if(selected&&selected.kind==='species'){const pts=selected.range_points||[];for(const p of pts){const [x,y]=proj(p[0],p[1]);svg.append(el('circle',{cx:x,cy:y,r:1.2,fill:'#6c3483','fill-opacity':.6}));}}}
drawMap();
</script></body></html>
"""


def viewer_html(graph: dict, projection: dict, summary: dict, geo: dict | None = None, thumbs: dict | None = None) -> str:
    # The viewer carries only the interactive kinds; the complete graph stays in graph.json.
    keep_kinds = {"specimen", "species", "colour", "shape_class", "trait_value", "location", "site", "region", "image"}
    keep_ids = {n["id"] for n in graph["nodes"] if n["kind"] in keep_kinds}
    slim = {"schema": graph["schema"], "meta": graph.get("meta", {}),
            "nodes": [{k: v for k, v in n.items() if k not in {"features"}} for n in graph["nodes"] if n["id"] in keep_ids],
            "edges": [e for e in graph["edges"] if e["source"] in keep_ids and e["target"] in keep_ids],
            "omitted": sorted({n["kind"] for n in graph["nodes"] if n["id"] not in keep_ids})}
    payload = json.dumps({"graph": slim, "projection": projection, "summary": summary, "geo": geo or [], "thumbs": thumbs or {}}, ensure_ascii=False)
    payload = payload.replace("</", "<\\/")
    return VIEWER_TEMPLATE.replace("__DATA__", payload)
