"""Model-free image descriptors: foreground shape, colour, texture and hashes.

Everything is numpy + Pillow. The foreground mask is a heuristic (distance
from the border background colour, Otsu threshold, largest component) and
each record states which method was used so a full-frame fallback is never
mistaken for a measured specimen outline.
"""

from __future__ import annotations

import math
import warnings

import numpy as np
from PIL import Image, ImageOps

try:
    from scipy import ndimage as _ndimage
except ImportError:  # pragma: no cover - optional
    _ndimage = None

ANALYSIS_MAX_SIDE = 512
BORDER_PX = 12
MIN_FOREGROUND, MAX_FOREGROUND = 0.003, 0.90

COLOUR_VOCABULARY = ["black", "brown", "grey", "white", "yellow", "orange", "red", "green", "blue", "purple", "other"]
# Reference colours in sRGB; matched in Lab after the achromatic rules.
COLOUR_REFERENCES = {
    "brown": [(120, 72, 30), (92, 51, 23), (150, 100, 50), (72, 45, 20)],
    "yellow": [(230, 200, 40), (250, 230, 90), (200, 180, 30)],
    "orange": [(240, 130, 30), (220, 100, 20), (255, 160, 60)],
    "red": [(200, 30, 30), (150, 20, 20), (230, 60, 60)],
    "green": [(40, 140, 50), (90, 160, 60), (20, 90, 30)],
    "blue": [(30, 60, 200), (60, 110, 220), (20, 40, 120)],
    "purple": [(120, 40, 160), (160, 80, 200), (80, 20, 110)],
}

SHAPE_NAMES = ["area_fraction", "bbox_aspect", "elongation", "solidity", "circularity", "extent_ratio",
               "hu1", "hu2", "hu3", "hu4", "hu5", "hu6", "hu7"]
COLOUR_NAMES = ["mean_L", "mean_a", "mean_b", "std_L", "std_a", "std_b", "chroma_mean"]
TEXTURE_NAMES = ["edge_density", "sharpness_log", "local_contrast"]
VECTOR_NAMES = SHAPE_NAMES + COLOUR_NAMES + TEXTURE_NAMES + ["colour_" + c for c in COLOUR_VOCABULARY]


# -- colour space ------------------------------------------------------------
def srgb_to_lab(rgb: np.ndarray) -> np.ndarray:
    """rgb float array (..., 3) in 0..1 -> CIE Lab (D65)."""
    c = np.where(rgb <= 0.04045, rgb / 12.92, ((rgb + 0.055) / 1.055) ** 2.4)
    m = np.array([[0.4124564, 0.3575761, 0.1804375],
                  [0.2126729, 0.7151522, 0.0721750],
                  [0.0193339, 0.1191920, 0.9503041]])
    xyz = c @ m.T
    xyz = xyz / np.array([0.95047, 1.0, 1.08883])
    f = np.where(xyz > 0.008856, np.cbrt(xyz), 7.787 * xyz + 16 / 116)
    L = 116 * f[..., 1] - 16
    a = 500 * (f[..., 0] - f[..., 1])
    b = 200 * (f[..., 1] - f[..., 2])
    return np.stack([L, a, b], axis=-1)


_REF_LAB = {name: srgb_to_lab(np.array(vals, dtype=float) / 255.0) for name, vals in COLOUR_REFERENCES.items()}


def name_colour(lab: np.ndarray) -> str:
    L, a, b = float(lab[0]), float(lab[1]), float(lab[2])
    chroma = math.hypot(a, b)
    if chroma < 14:
        if L < 28:
            return "black"
        if L > 82:
            return "white"
        return "grey"
    if L < 18:
        return "black"
    best, best_d = "other", 1e9
    for name, refs in _REF_LAB.items():
        d = float(np.min(np.linalg.norm(refs - lab, axis=1)))
        if d < best_d:
            best, best_d = name, d
    return best if best_d < 45 else "other"


# -- helpers -----------------------------------------------------------------
def otsu(values: np.ndarray, bins: int = 256) -> float:
    hist, edges = np.histogram(values, bins=bins)
    hist = hist.astype(float)
    total = hist.sum()
    if total == 0:
        return 0.0
    centres = (edges[:-1] + edges[1:]) / 2
    w0 = np.cumsum(hist)
    w1 = total - w0
    sum0 = np.cumsum(hist * centres)
    m0 = sum0 / np.maximum(w0, 1e-9)
    m1 = (sum0[-1] - sum0) / np.maximum(w1, 1e-9)
    var = w0 * w1 * (m0 - m1) ** 2
    var[w1 <= 0] = -1
    return float(centres[int(np.argmax(var))])


def largest_component(mask: np.ndarray) -> np.ndarray:
    if _ndimage is None:
        return mask
    labels, count = _ndimage.label(mask)
    if count <= 1:
        return mask
    sizes = _ndimage.sum(mask, labels, range(1, count + 1))
    keep = int(np.argmax(sizes)) + 1
    return labels == keep


def clean_mask(mask: np.ndarray) -> np.ndarray:
    if _ndimage is None:
        return mask
    mask = _ndimage.binary_opening(mask, iterations=1)
    mask = _ndimage.binary_closing(mask, iterations=2)
    mask = _ndimage.binary_fill_holes(mask)
    return mask


def foreground_mask(rgb: np.ndarray) -> tuple[np.ndarray, dict]:
    """Return (mask, detail). ``rgb`` is float (H, W, 3) in 0..1."""
    h, w = rgb.shape[:2]
    lab = srgb_to_lab(rgb)
    border = np.concatenate([lab[:BORDER_PX].reshape(-1, 3), lab[-BORDER_PX:].reshape(-1, 3),
                             lab[:, :BORDER_PX].reshape(-1, 3), lab[:, -BORDER_PX:].reshape(-1, 3)])
    background = np.median(border, axis=0)
    dist = np.linalg.norm(lab - background, axis=-1)
    threshold = max(otsu(dist.ravel()), 8.0)
    mask = dist > threshold
    mask = clean_mask(mask)
    mask = largest_component(mask)
    fraction = float(mask.mean())
    detail = {"method": "border-background-otsu-largest-component-v1", "threshold_lab": round(threshold, 2),
              "background_lab": [round(float(v), 2) for v in background], "foreground_fraction": round(fraction, 5)}
    if not MIN_FOREGROUND <= fraction <= MAX_FOREGROUND:
        detail.update(method="full_frame_fallback", reason=f"foreground fraction {fraction:.4f} outside plausible range")
        return np.ones((h, w), dtype=bool), detail
    return mask.astype(bool), detail


# -- shape -------------------------------------------------------------------
def hu_moments(mask: np.ndarray) -> list[float]:
    ys, xs = np.nonzero(mask)
    if xs.size == 0:
        return [0.0] * 7
    x, y = xs.astype(float), ys.astype(float)
    m00 = x.size
    cx, cy = x.mean(), y.mean()
    dx, dy = x - cx, y - cy

    def mu(p, q):
        return float(np.sum(dx ** p * dy ** q))

    def eta(p, q):
        return mu(p, q) / (m00 ** (1 + (p + q) / 2))

    n20, n02, n11 = eta(2, 0), eta(0, 2), eta(1, 1)
    n30, n03, n21, n12 = eta(3, 0), eta(0, 3), eta(2, 1), eta(1, 2)
    h1 = n20 + n02
    h2 = (n20 - n02) ** 2 + 4 * n11 ** 2
    h3 = (n30 - 3 * n12) ** 2 + (3 * n21 - n03) ** 2
    h4 = (n30 + n12) ** 2 + (n21 + n03) ** 2
    h5 = (n30 - 3 * n12) * (n30 + n12) * ((n30 + n12) ** 2 - 3 * (n21 + n03) ** 2) + \
         (3 * n21 - n03) * (n21 + n03) * (3 * (n30 + n12) ** 2 - (n21 + n03) ** 2)
    h6 = (n20 - n02) * ((n30 + n12) ** 2 - (n21 + n03) ** 2) + 4 * n11 * (n30 + n12) * (n21 + n03)
    h7 = (3 * n21 - n03) * (n30 + n12) * ((n30 + n12) ** 2 - 3 * (n21 + n03) ** 2) - \
         (n30 - 3 * n12) * (n21 + n03) * (3 * (n30 + n12) ** 2 - (n21 + n03) ** 2)
    out = []
    for hval in (h1, h2, h3, h4, h5, h6, h7):
        out.append(0.0 if hval == 0 else float(-math.copysign(1, hval) * math.log10(abs(hval))))
    return out


def shape_features(mask: np.ndarray) -> dict:
    h, w = mask.shape
    ys, xs = np.nonzero(mask)
    area = int(xs.size)
    if area == 0:
        return {name: 0.0 for name in SHAPE_NAMES} | {"bbox": [0, 0, 1, 1], "orientation_deg": 0.0}
    x0, x1, y0, y1 = xs.min(), xs.max() + 1, ys.min(), ys.max() + 1
    bw, bh = x1 - x0, y1 - y0
    cov = np.cov(np.stack([xs, ys]).astype(float)) if area > 2 else np.eye(2)
    eig, vec = np.linalg.eigh(cov)
    l_small, l_big = max(eig[0], 1e-9), max(eig[1], 1e-9)
    elongation = float(math.sqrt(l_big / l_small))
    orientation = float(math.degrees(math.atan2(vec[1, 1], vec[0, 1])))
    edge = mask & ~(np.roll(mask, 1, 0) & np.roll(mask, -1, 0) & np.roll(mask, 1, 1) & np.roll(mask, -1, 1))
    perimeter = max(int(edge.sum()), 1)
    circularity = float(min(1.0, 4 * math.pi * area / perimeter ** 2))
    hu = hu_moments(mask)
    return {
        "area_fraction": float(area / (h * w)), "bbox_aspect": float(bw / bh), "elongation": elongation,
        "solidity": float(area / (bw * bh)), "circularity": circularity,
        "extent_ratio": float(max(bw, bh) / max(h, w)),
        **{f"hu{i+1}": hu[i] for i in range(7)},
        "bbox": [float(x0 / w), float(y0 / h), float(bw / w), float(bh / h)], "orientation_deg": orientation,
    }


# -- colour ------------------------------------------------------------------
def kmeans(points: np.ndarray, k: int, iterations: int = 12, seed: int = 7) -> tuple[np.ndarray, np.ndarray]:
    rng = np.random.default_rng(seed)
    n = len(points)
    k = min(k, n)
    centres = [points[rng.integers(n)]]
    for _ in range(1, k):
        d = np.min(np.linalg.norm(points[:, None, :] - np.array(centres)[None], axis=-1) ** 2, axis=1)
        probs = d / d.sum() if d.sum() > 0 else np.full(n, 1 / n)
        centres.append(points[rng.choice(n, p=probs)])
    centres = np.array(centres, dtype=float)
    labels = np.zeros(n, dtype=int)
    for _ in range(iterations):
        labels = np.argmin(np.linalg.norm(points[:, None, :] - centres[None], axis=-1), axis=1)
        for j in range(k):
            members = points[labels == j]
            if len(members):
                centres[j] = members.mean(axis=0)
    return centres, labels


def lab_to_srgb(lab: np.ndarray) -> tuple[int, int, int]:
    L, a, b = lab
    fy = (L + 16) / 116
    fx, fz = fy + a / 500, fy - b / 200

    def finv(t):
        return t ** 3 if t ** 3 > 0.008856 else (t - 16 / 116) / 7.787

    xyz = np.array([finv(fx) * 0.95047, finv(fy), finv(fz) * 1.08883])
    m = np.array([[3.2404542, -1.5371385, -0.4985314],
                  [-0.9692660, 1.8760108, 0.0415560],
                  [0.0556434, -0.2040259, 1.0572252]])
    c = xyz @ m.T
    c = np.where(c <= 0.0031308, 12.92 * c, 1.055 * np.power(np.clip(c, 0, None), 1 / 2.4) - 0.055)
    return tuple(int(v) for v in np.clip(c * 255, 0, 255).round())


def colour_features(rgb: np.ndarray, mask: np.ndarray, k: int = 5, sample: int = 20000, seed: int = 7) -> dict:
    lab = srgb_to_lab(rgb)[mask]
    if lab.shape[0] == 0:
        lab = srgb_to_lab(rgb).reshape(-1, 3)
    rng = np.random.default_rng(seed)
    pts = lab if lab.shape[0] <= sample else lab[rng.choice(lab.shape[0], sample, replace=False)]
    centres, labels = kmeans(pts, k, seed=seed)
    counts = np.bincount(labels, minlength=len(centres)) / len(labels)
    dominant = []
    vocab = {name: 0.0 for name in COLOUR_VOCABULARY}
    for j in np.argsort(-counts):
        if counts[j] <= 0:
            continue
        name = name_colour(centres[j])
        vocab[name] += float(counts[j])
        dominant.append({"name": name, "fraction": round(float(counts[j]), 4),
                         "lab": [round(float(v), 2) for v in centres[j]], "rgb": lab_to_srgb(centres[j])})
    hsv = np.asarray(Image.fromarray((rgb * 255).astype(np.uint8)).convert("HSV")).reshape(-1, 3)[mask.ravel()]
    hist, _ = np.histogramdd(hsv.astype(float), bins=(8, 4, 4), range=((0, 256), (0, 256), (0, 256)))
    hist = (hist / max(hist.sum(), 1)).ravel()
    mean, std = lab.mean(axis=0), lab.std(axis=0)
    return {
        "mean_L": float(mean[0]), "mean_a": float(mean[1]), "mean_b": float(mean[2]),
        "std_L": float(std[0]), "std_a": float(std[1]), "std_b": float(std[2]),
        "chroma_mean": float(np.hypot(lab[:, 1], lab[:, 2]).mean()),
        "dominant": dominant, "vocabulary": {k_: round(v, 4) for k_, v in vocab.items()},
        "hsv_hist": [round(float(v), 5) for v in hist],
    }


# -- texture -----------------------------------------------------------------
def convolve2d(img: np.ndarray, kernel: np.ndarray) -> np.ndarray:
    if _ndimage is not None:
        return _ndimage.convolve(img, kernel, mode="nearest")
    kh, kw = kernel.shape
    padded = np.pad(img, ((kh // 2, kh // 2), (kw // 2, kw // 2)), mode="edge")
    out = np.zeros_like(img)
    for i in range(kh):
        for j in range(kw):
            out += kernel[i, j] * padded[i:i + img.shape[0], j:j + img.shape[1]]
    return out


def texture_features(rgb: np.ndarray, mask: np.ndarray) -> dict:
    grey = rgb @ np.array([0.299, 0.587, 0.114])
    sx = convolve2d(grey, np.array([[-1, 0, 1], [-2, 0, 2], [-1, 0, 1]], dtype=float))
    sy = convolve2d(grey, np.array([[-1, -2, -1], [0, 0, 0], [1, 2, 1]], dtype=float))
    grad = np.hypot(sx, sy)
    lap = convolve2d(grey, np.array([[0, 1, 0], [1, -4, 1], [0, 1, 0]], dtype=float))
    inside = grad[mask]
    return {"edge_density": float((inside > 0.25).mean()) if inside.size else 0.0,
            "sharpness_log": float(math.log10(lap[mask].var() + 1e-9)),
            "local_contrast": float(grey[mask].std()) if mask.any() else 0.0}


# -- hashes ------------------------------------------------------------------
def _bits_to_hex(bits: np.ndarray) -> str:
    return "".join(f"{int(''.join(str(int(b)) for b in bits.ravel()[i:i+4]), 2):x}" for i in range(0, bits.size, 4))


def dhash(grey_image: Image.Image) -> str:
    small = np.asarray(grey_image.resize((9, 8), Image.Resampling.LANCZOS), dtype=float)
    return _bits_to_hex(small[:, 1:] > small[:, :-1])


def phash(grey_image: Image.Image) -> str:
    small = np.asarray(grey_image.resize((32, 32), Image.Resampling.LANCZOS), dtype=float)
    n = 32
    k = np.arange(n)
    dct_m = np.cos(np.pi / n * (k[:, None] + 0.5) * k[None, :]).T
    dct = dct_m @ small @ dct_m.T
    low = dct[:8, :8].ravel()[1:]
    return _bits_to_hex(dct[:8, :8] > np.median(low))


def hamming(hex_a: str, hex_b: str) -> int:
    return bin(int(hex_a, 16) ^ int(hex_b, 16)).count("1")


# -- entry point -------------------------------------------------------------
def load_rgb(path) -> tuple[np.ndarray, dict]:
    with Image.open(path) as im:
        im = ImageOps.exif_transpose(im)
        original = im.size
        im = im.convert("RGB")
        im.thumbnail((ANALYSIS_MAX_SIDE, ANALYSIS_MAX_SIDE), Image.Resampling.LANCZOS)
        rgb = np.asarray(im, dtype=float) / 255.0
        grey = im.convert("L")
    return rgb, {"original_size": list(original), "analysis_size": list(im.size), "grey": grey}


def extract(path, mask_out=None) -> dict:
    """Extract descriptors; optionally save the analysis-scale mask PNG as evidence."""
    rgb, meta = load_rgb(path)
    grey = meta.pop("grey")
    mask, mask_detail = foreground_mask(rgb)
    if mask_out is not None:
        Image.fromarray((mask * 255).astype(np.uint8)).save(mask_out)
        mask_detail["mask_file"] = str(mask_out)
    shape = shape_features(mask) if mask_detail["method"] != "full_frame_fallback" else \
        {name: None for name in SHAPE_NAMES} | {"bbox": [0.0, 0.0, 1.0, 1.0], "orientation_deg": None}
    colour = colour_features(rgb, mask)
    texture = texture_features(rgb, mask)
    hashes = {"dhash": dhash(grey), "phash": phash(grey)}
    vector = [shape.get(n) for n in SHAPE_NAMES] + [colour[n] for n in COLOUR_NAMES] + \
             [texture[n] for n in TEXTURE_NAMES] + [colour["vocabulary"][c] for c in COLOUR_VOCABULARY]
    return {"schema": "specimen-image-features-v1", **meta, "mask": mask_detail, "shape": shape,
            "colour": colour, "texture": texture, "hashes": hashes,
            "vector": [None if v is None else float(v) for v in vector], "vector_names": VECTOR_NAMES}


def aggregate(image_features: list[dict]) -> dict:
    """Mean vector across a specimen's images (NaN-aware); union of dominant colours."""
    if not image_features:
        return {"vector": [None] * len(VECTOR_NAMES), "vector_names": VECTOR_NAMES, "colours": {}, "image_count": 0}
    arr = np.array([[np.nan if v is None else v for v in f["vector"]] for f in image_features], dtype=float)
    with np.errstate(all="ignore"), warnings.catch_warnings():
        warnings.simplefilter("ignore", RuntimeWarning)
        mean = np.nanmean(arr, axis=0)
    colours: dict[str, float] = {}
    for f in image_features:
        for name, frac in f["colour"]["vocabulary"].items():
            colours[name] = colours.get(name, 0.0) + frac / len(image_features)
    return {"vector": [None if np.isnan(v) else float(v) for v in mean], "vector_names": VECTOR_NAMES,
            "colours": {k: round(v, 4) for k, v in colours.items() if v > 0},
            "image_count": len(image_features),
            "mask_methods": sorted({f["mask"]["method"] for f in image_features})}
