"""Collection-location loading, validation and geographic derivations.

Accepts a permissive CSV: column names are normalised and common aliases
(lat/latitude/decimalLatitude, lon/lng/longitude, locality/site/place,
country, date/collected_date/eventDate, site_id) are recognised. Unknown
columns are preserved in the record.
"""

from __future__ import annotations

import csv
import datetime as dt
import math
from pathlib import Path

from .store import canonical, clean_specimen_id, digest

ALIASES = {
    "specimen_id": ["specimen_id", "specimen", "id", "catalog_number", "catalogue_number", "catalognumber"],
    "latitude": ["latitude", "lat", "decimallatitude", "decimal_latitude", "y"],
    "longitude": ["longitude", "lon", "lng", "long", "decimallongitude", "decimal_longitude", "x"],
    "locality": ["locality", "site", "place", "location", "site_name", "locality_name"],
    "country": ["country", "country_name", "countrycode"],
    "collected_date": ["collected_date", "date", "eventdate", "event_date", "collection_date", "date_collected"],
    "site_id": ["site_id", "siteid", "site_code", "station"],
    "uncertainty_m": ["uncertainty_m", "coordinateuncertaintyinmeters", "uncertainty"],
}
DATE_FORMATS = ("%Y-%m-%d", "%d/%m/%Y", "%d/%m/%y", "%Y/%m/%d", "%d-%m-%Y", "%Y-%m", "%Y")
EARTH_RADIUS_KM = 6371.0088


def normalise_row(row: dict) -> dict:
    lowered = {k.strip().lower().replace(" ", "_"): (v or "").strip() for k, v in row.items() if k}
    out: dict = {}
    for canon, names in ALIASES.items():
        for name in names:
            if name in lowered and lowered[name] != "":
                out[canon] = lowered.pop(name)
                break
        for name in names:
            lowered.pop(name, None)
    out["extra"] = lowered
    return out


def parse_date(text: str | None) -> str | None:
    if not text:
        return None
    for fmt in DATE_FORMATS:
        try:
            return dt.datetime.strptime(text, fmt).date().isoformat()
        except ValueError:
            continue
    return None


def parse_coordinate(text: str, low: float, high: float, name: str) -> float:
    try:
        value = float(text)
    except (TypeError, ValueError):
        raise ValueError(f"{name} {text!r} is not a number") from None
    if not math.isfinite(value) or not low <= value <= high:
        raise ValueError(f"{name} {value} outside [{low}, {high}]")
    return value


def haversine_km(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dphi, dlam = p2 - p1, math.radians(lon2 - lon1)
    a = math.sin(dphi / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dlam / 2) ** 2
    return 2 * EARTH_RADIUS_KM * math.asin(math.sqrt(a))


def grid_cell(lat: float, lon: float, size_degrees: float) -> str:
    lat0 = math.floor(lat / size_degrees) * size_degrees
    lon0 = math.floor(lon / size_degrees) * size_degrees
    return f"{lat0:g},{lon0:g}"


def location_id(lat: float, lon: float, locality: str | None) -> str:
    return "location:" + digest([round(lat, 5), round(lon, 5), (locality or "").lower()])[:12]


def load_locations(path, grid_degrees: float = 1.0) -> dict:
    """Return ``{"records": {specimen_id: record}, "problems": [..]}``."""
    records: dict[str, dict] = {}
    problems: list[str] = []
    with open(path, newline="", encoding="utf-8-sig") as fh:
        for line_no, raw in enumerate(csv.DictReader(fh), start=2):
            row = normalise_row(raw)
            try:
                specimen_id = clean_specimen_id(row.get("specimen_id", ""))
                lat = parse_coordinate(row.get("latitude"), -90, 90, "latitude")
                lon = parse_coordinate(row.get("longitude"), -180, 180, "longitude")
            except ValueError as exc:
                problems.append(f"line {line_no}: {exc}")
                continue
            if specimen_id in records:
                problems.append(f"line {line_no}: duplicate specimen {specimen_id}; first row kept")
                continue
            date_iso = parse_date(row.get("collected_date"))
            if row.get("collected_date") and not date_iso:
                problems.append(f"line {line_no}: unparsed date {row['collected_date']!r} kept as text only")
            uncertainty = None
            if row.get("uncertainty_m"):
                try:
                    uncertainty = float(row["uncertainty_m"])
                except ValueError:
                    problems.append(f"line {line_no}: bad uncertainty {row['uncertainty_m']!r}")
            records[specimen_id] = {
                "specimen_id": specimen_id, "latitude": lat, "longitude": lon,
                "locality": row.get("locality") or None, "country": row.get("country") or None,
                "collected_date": date_iso, "collected_date_text": row.get("collected_date") or None,
                "site_id": row.get("site_id") or None, "uncertainty_m": uncertainty,
                "grid_cell": grid_cell(lat, lon, grid_degrees), "grid_degrees": grid_degrees,
                "location_id": location_id(lat, lon, row.get("locality")),
                "extra": row["extra"], "raw": {k: v for k, v in raw.items() if k}, "source_line": line_no,
            }
    return {"records": records, "problems": problems, "source": str(Path(path))}


def distance_matrix(records: dict[str, dict], order: list[str]) -> list[list[float | None]]:
    out = []
    for a in order:
        row = []
        for b in order:
            ra, rb = records.get(a), records.get(b)
            row.append(None if not ra or not rb else haversine_km(ra["latitude"], ra["longitude"], rb["latitude"], rb["longitude"]))
        out.append(row)
    return out


def write_template(path) -> None:
    Path(path).write_text("specimen_id,latitude,longitude,locality,country,collected_date,site_id\n"
                          "example01,51.4966,-0.1764,Natural History Museum garden,United Kingdom,2026-09-01,NHM\n")
