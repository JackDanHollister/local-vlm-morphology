"""Content-hashed image store with plain JSON records.

Assets are written once under ``assets/<sha256>.<ext>`` and never modified.
Records (specimens, images, features, model runs) live as JSON so they can be
inspected and diffed without tooling. The layout is deliberately close to the
openscan-specimen-lab store so records can be cross-referenced later.
"""

from __future__ import annotations

import csv
import datetime as dt
import hashlib
import io
import json
import re
import uuid
from pathlib import Path

from PIL import Image

IMAGE_SUFFIXES = {".jpg", ".jpeg", ".png", ".tif", ".tiff", ".webp"}
FORMAT_EXT = {"JPEG": ".jpg", "PNG": ".png", "TIFF": ".tif", "WEBP": ".webp"}
SPECIMEN_ID = re.compile(r"[A-Za-z0-9:_.-]{1,80}")


def now() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat()


def uid(prefix: str) -> str:
    return prefix + "_" + uuid.uuid4().hex[:16]


def canonical(value) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False)


def digest(value) -> str:
    return hashlib.sha256(canonical(value).encode()).hexdigest()


def write_new(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("xb") as out:
        out.write(data)


def clean_specimen_id(text: str) -> str:
    cleaned = re.sub(r"[^A-Za-z0-9:_.-]+", "_", text.strip()).strip("_")
    if not cleaned or not SPECIMEN_ID.fullmatch(cleaned):
        raise ValueError(f"Cannot derive a valid specimen ID from {text!r}")
    return cleaned


def parse_filename(name: str) -> tuple[str, str | None]:
    """``beetle07__dorsal.jpg`` -> (``beetle07``, ``dorsal``); no ``__`` -> view None."""
    stem = Path(name).stem
    if "__" in stem:
        specimen, view = stem.split("__", 1)
        return clean_specimen_id(specimen), view.strip() or None
    return clean_specimen_id(stem), None


class Store:
    def __init__(self, root):
        self.root = Path(root).resolve()
        for sub in ("assets", "features", "runs"):
            (self.root / sub).mkdir(parents=True, exist_ok=True)
        self.index_path = self.root / "index.json"
        if self.index_path.exists():
            self._index = json.loads(self.index_path.read_text())
        else:
            self._index = {"schema": "specimen-graph-store-v1", "specimens": {}, "images": {}}
            self._save()

    def _save(self) -> None:
        tmp = self.index_path.with_suffix(".json.tmp")
        tmp.write_text(json.dumps(self._index, indent=1, sort_keys=True))
        tmp.replace(self.index_path)

    # -- specimens -----------------------------------------------------------
    def specimen(self, specimen_id: str, label: str | None = None, **extra) -> dict:
        if not SPECIMEN_ID.fullmatch(specimen_id):
            raise ValueError(f"Invalid specimen ID {specimen_id!r}")
        record = self._index["specimens"].get(specimen_id)
        if record is None:
            record = {"id": specimen_id, "label": label or specimen_id, "created": now(), "extra": {}}
            self._index["specimens"][specimen_id] = record
        elif label and record["label"] != label:
            record["label"] = label
        if extra:
            record["extra"].update({k: v for k, v in extra.items() if v not in (None, "")})
        self._save()
        return record

    def specimens(self) -> list[dict]:
        return [self._index["specimens"][k] for k in sorted(self._index["specimens"])]

    # -- images --------------------------------------------------------------
    def add_image(self, specimen_id: str, source, *, view: str | None = None, source_name: str | None = None) -> dict:
        if specimen_id not in self._index["specimens"]:
            raise ValueError(f"Unknown specimen {specimen_id!r}")
        raw = Path(source).read_bytes() if isinstance(source, (str, Path)) else bytes(source)
        with Image.open(io.BytesIO(raw)) as im:
            im.verify()
        with Image.open(io.BytesIO(raw)) as im:
            width, height, fmt = im.size[0], im.size[1], im.format
        if fmt not in FORMAT_EXT:
            raise ValueError(f"Unsupported image format {fmt!r}; use JPEG, PNG, TIFF or WebP")
        sha = hashlib.sha256(raw).hexdigest()
        for existing in self._index["images"].values():
            if existing["sha256"] == sha and existing["specimen_id"] == specimen_id:
                return existing
        filename = "assets/" + sha + FORMAT_EXT[fmt]
        target = self.root / filename
        if not target.exists():
            write_new(target, raw)
        record = {"id": uid("image"), "specimen_id": specimen_id, "width": width, "height": height,
                  "format": fmt, "sha256": sha, "path": filename, "view": view,
                  "source_name": source_name or (Path(source).name if isinstance(source, (str, Path)) else None),
                  "source_path": str(Path(source).resolve()) if isinstance(source, (str, Path)) else None,
                  "created": now()}
        self._index["images"][record["id"]] = record
        self._save()
        return record

    def image(self, image_id: str) -> dict:
        try:
            return self._index["images"][image_id]
        except KeyError:
            raise ValueError(f"Unknown image {image_id!r}") from None

    def images(self, specimen_id: str | None = None) -> list[dict]:
        items = sorted(self._index["images"].values(), key=lambda i: (i["specimen_id"], i["created"]))
        return [i for i in items if specimen_id is None or i["specimen_id"] == specimen_id]

    def image_path(self, image_id: str, verify: bool = False) -> Path:
        record = self.image(image_id)
        path = (self.root / record["path"]).resolve()
        if not path.is_relative_to(self.root / "assets"):
            raise ValueError("Asset path outside store")
        if verify and hashlib.sha256(path.read_bytes()).hexdigest() != record["sha256"]:
            raise ValueError(f"Asset for {image_id} was modified")
        return path

    # -- features ------------------------------------------------------------
    def put_features(self, image_id: str, data: dict) -> dict:
        self.image(image_id)
        record = {"image_id": image_id, "created": now(), **data}
        (self.root / "features" / f"{image_id}.json").write_text(canonical(record) + "\n")
        return record

    def features(self, image_id: str) -> dict | None:
        path = self.root / "features" / f"{image_id}.json"
        return json.loads(path.read_text()) if path.exists() else None

    def all_features(self) -> dict[str, dict]:
        return {p.stem: json.loads(p.read_text()) for p in sorted((self.root / "features").glob("image_*.json"))}

    # -- model runs ----------------------------------------------------------
    def run_dir(self, run_id: str) -> Path:
        return self.root / "runs" / run_id

    def runs(self) -> list[dict]:
        out = []
        for path in sorted((self.root / "runs").glob("run_*/request.json")):
            request = json.loads(path.read_text())
            terminal = path.with_name("terminal.json")
            result = path.with_name("result.json")
            request["terminal"] = json.loads(terminal.read_text()) if terminal.exists() else {"state": "running"}
            reval = path.with_name("revalidation.json")
            if reval.exists():
                r = json.loads(reval.read_text())
                request["terminal"] = {**request["terminal"], "original_state": request["terminal"].get("state"),
                                       "original_errors": request["terminal"].get("errors"), "state": r["state"],
                                       "errors": r["errors"], "normalisations": r["normalisations"], "revalidated": r["finished"]}
            request["result"] = json.loads(result.read_text()) if result.exists() else None
            out.append(request)
        return out

    def snapshot(self) -> dict:
        return {"specimens": self.specimens(), "images": self.images(),
                "features": self.all_features(), "runs": self.runs()}


def ingest_folder(store: Store, folder, manifest=None, log=None) -> list[dict]:
    """Register every image in ``folder``; optional CSV manifest maps files to specimens.
    Unreadable files are skipped and reported through ``log`` rather than aborting."""
    folder = Path(folder)
    mapping: dict[str, dict] = {}
    if manifest and Path(manifest).exists():
        with open(manifest, newline="", encoding="utf-8-sig") as fh:
            for row in csv.DictReader(fh):
                row = {k.strip().lower(): (v or "").strip() for k, v in row.items() if k}
                name = row.get("image") or row.get("file") or row.get("filename")
                if name:
                    mapping[Path(name).name] = row
    added = []
    for path in sorted(p for p in folder.rglob("*") if p.suffix.lower() in IMAGE_SUFFIXES and not p.name.startswith(".")):
        if mapping and path.name not in mapping:
            continue  # a manifest defines the dataset; unlisted files are ignored
        row = mapping.get(path.name, {})
        if row.get("specimen_id"):
            specimen_id, view = clean_specimen_id(row["specimen_id"]), row.get("view") or None
        else:
            specimen_id, view = parse_filename(path.name)
        extra = {k: v for k, v in row.items() if k not in {"image", "file", "filename", "specimen_id", "view", "label"}}
        try:
            store.specimen(specimen_id, row.get("label") or None, **extra)
            added.append(store.add_image(specimen_id, path, view=view, source_name=path.name))
        except (OSError, ValueError, Exception) as exc:
            if log:
                log(f"skipped {path.name}: {type(exc).__name__}: {exc}")
    return added
