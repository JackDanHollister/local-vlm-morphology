"""CLI: python -m specimen_graph <command> [options]."""

from __future__ import annotations

import argparse
import json
import platform
import sys
from pathlib import Path

from . import __version__, features as feat
from .store import Store, ingest_folder

PROJECT = Path(__file__).resolve().parent.parent
DEFAULT_STORE = PROJECT / "store"
DEFAULT_OUT = PROJECT / "outputs"
DEFAULT_CONFIG = PROJECT / "config" / "graph.json"


def log(msg: str) -> None:
    print(msg, file=sys.stderr)


def run_metadata() -> dict:
    import numpy, networkx, PIL
    try:
        import scipy
        scipy_v = scipy.__version__
    except ImportError:
        scipy_v = None
    return {"specimen_graph": __version__, "python": platform.python_version(), "executable": sys.executable,
            "numpy": numpy.__version__, "networkx": networkx.__version__, "pillow": PIL.__version__, "scipy": scipy_v}


def cmd_demo(args):
    from .demo import generate
    result = generate(args.out, n=args.n, seed=args.seed)
    log(f"wrote {len(result['images'])} images and {result['locations']}")
    print(json.dumps(result, indent=1))


def cmd_ingest(args):
    store = Store(args.store)
    added = ingest_folder(store, args.images, args.manifest, log=log)
    log(f"{len(added)} images registered for {len(store.specimens())} specimens in {store.root}")


def cmd_features(args):
    store = Store(args.store)
    done = 0
    for image in store.images():
        if store.features(image["id"]) and not args.force:
            continue
        mask_path = store.root / "features" / f"{image['id']}_mask.png"
        result = feat.extract(store.image_path(image["id"], verify=True), mask_out=mask_path)
        store.put_features(image["id"], result)
        done += 1
        log(f"{image['specimen_id']:>12} {image['source_name']}: mask={result['mask']['method']} colours={[c['name'] for c in result['colour']['dominant'][:3]]}")
    log(f"features extracted for {done} images")


def cmd_locations(args):
    from .locations import load_locations, write_template
    if args.template:
        write_template(args.template)
        log(f"template written to {args.template}")
        return
    store = Store(args.store)
    grid = load_config(args.config).get("grid_degrees", 1.0)
    result = load_locations(args.csv, grid_degrees=grid)
    (store.root / "locations.json").write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    known = {s["id"] for s in store.specimens()}
    unmatched = sorted(set(result["records"]) - known)
    missing = sorted(known - set(result["records"]))
    log(f"{len(result['records'])} located rows; {len(result['problems'])} problems; {len(unmatched)} rows without images; {len(missing)} specimens without a location")
    for p in result["problems"]:
        log("  problem: " + p)
    if unmatched:
        log("  rows without images: " + ", ".join(unmatched))
    if missing:
        log("  specimens without location: " + ", ".join(missing))


def cmd_observe(args):
    from .observe import observe_all
    store = Store(args.store)
    wanted = list(args.specimen or [])
    if args.specimen_file:
        wanted += [line.strip() for line in Path(args.specimen_file).read_text().splitlines() if line.strip()]
    results = observe_all(store, args.provider, specimens=wanted or None, skip_usable=not args.force, timeout=args.timeout, workers=args.workers, log=log)
    states = {}
    for r in results:
        states[r["terminal"]["state"]] = states.get(r["terminal"]["state"], 0) + 1
    log(f"runs: {states}")


def cmd_revalidate(args):
    from .observe import revalidate
    log(str(revalidate(Store(args.store), log=log)))


def load_geo(path) -> dict | None:
    path = Path(path) if path else PROJECT / "data" / "geo" / "british_isles_outline.json"
    return json.loads(path.read_text()) if path.exists() else None


def load_config(path) -> dict:
    path = Path(path) if path else DEFAULT_CONFIG
    return json.loads(path.read_text()) if path.exists() else {}


def cmd_graph(args):
    from . import analysis, export, graph as graph_mod
    from .locations import load_locations
    store = Store(args.store)
    cfg = load_config(args.config)
    if args.coarsen is not None:
        cfg.setdefault("privacy", {})["coordinate_decimals"] = args.coarsen
    if args.locations:
        locations = load_locations(args.locations, grid_degrees=cfg.get("grid_degrees", 1.0))
    elif (store.root / "locations.json").exists():
        locations = json.loads((store.root / "locations.json").read_text())
    else:
        locations = None
        log("no location data; run `locations --csv` first for geographic nodes")
    ranges = json.loads(Path(args.ranges).read_text()) if args.ranges else None
    snapshot = store.snapshot()
    G = graph_mod.build(snapshot, locations, cfg, ranges)
    P = graph_mod.specimen_projection(G)
    summary = analysis.report(G, locations, mantel_enabled=args.mantel, mantel_min_n=cfg.get("mantel_min_n", 8))
    metadata = {**run_metadata(), "config": G.graph["config"], "store": str(store.root)}
    files = export.write_all(G, P, args.out, summary, metadata, store=store, geo=load_geo(args.geo), ranges=ranges)
    Path(args.out, "report.md").write_text(analysis.report_markdown(summary))
    log(f"graph: {G.number_of_nodes()} nodes, {G.number_of_edges()} edges -> {args.out}")
    log("files: " + ", ".join(sorted(files)))


def cmd_all(args):
    cmd_ingest(args)
    cmd_features(args)
    if args.locations and Path(args.locations).exists():
        args.csv, args.template = args.locations, None
        cmd_locations(args)
    if args.observe:
        args.provider, args.specimen, args.force_observe = args.observe, None, False
        args.force = False
        cmd_observe(args)
    args.locations = None
    cmd_graph(args)


def main(argv=None):
    parser = argparse.ArgumentParser(prog="specimen_graph", description="Specimen image features + locations -> graph")
    parser.add_argument("--store", default=str(DEFAULT_STORE))
    parser.add_argument("--config", default=str(DEFAULT_CONFIG), help="graph config JSON")
    sub = parser.add_subparsers(dest="command", required=True)

    p = sub.add_parser("demo", help="generate synthetic images and a location CSV")
    p.add_argument("--out", default=str(PROJECT / "data" / "demo"))
    p.add_argument("--n", type=int, default=12)
    p.add_argument("--seed", type=int, default=7)
    p.set_defaults(func=cmd_demo)

    p = sub.add_parser("ingest", help="register images from a folder")
    p.add_argument("--images", required=True)
    p.add_argument("--manifest", help="optional CSV: image,specimen_id,label,view")
    p.set_defaults(func=cmd_ingest)

    p = sub.add_parser("features", help="extract model-free descriptors for every image")
    p.add_argument("--force", action="store_true")
    p.set_defaults(func=cmd_features)

    p = sub.add_parser("locations", help="load and validate the location CSV")
    p.add_argument("--csv")
    p.add_argument("--template", help="write a template CSV to this path and exit")
    p.set_defaults(func=cmd_locations)

    p = sub.add_parser("observe", help="run VLM observations per specimen")
    p.add_argument("--provider", default="claude", choices=["claude", "codex", "local", "dry-run"])
    p.add_argument("--specimen", action="append")
    p.add_argument("--specimen-file", help="text file with one specimen ID per line")
    p.add_argument("--force", action="store_true", help="re-run specimens that already have a usable run")
    p.add_argument("--timeout", type=int, default=300)
    p.add_argument("--workers", type=int, default=1)
    p.set_defaults(func=cmd_observe)

    p = sub.add_parser("revalidate", help="re-check failed model runs from their saved raw responses")
    p.set_defaults(func=cmd_revalidate)

    p = sub.add_parser("graph", help="build the graph, exports, viewer and report")
    p.add_argument("--out", default=str(DEFAULT_OUT))
    p.add_argument("--locations", help="location CSV (otherwise the last loaded one)")
    p.add_argument("--mantel", action="store_true", help="run the exploratory Mantel test")
    p.add_argument("--coarsen", type=int, help="round exported coordinates to N decimals and drop raw rows")
    p.add_argument("--ranges", help="species_ranges.json from scripts/fetch_gbif_ranges.py")
    p.add_argument("--geo", help="outline JSON for the offline map (default data/geo/british_isles_outline.json)")
    p.set_defaults(func=cmd_graph)

    p = sub.add_parser("all", help="ingest -> features -> locations -> [observe] -> graph")
    p.add_argument("--images", required=True)
    p.add_argument("--locations")
    p.add_argument("--manifest")
    p.add_argument("--observe", choices=["claude", "codex", "local", "dry-run"])
    p.add_argument("--out", default=str(DEFAULT_OUT))
    p.add_argument("--mantel", action="store_true")
    p.add_argument("--coarsen", type=int)
    p.add_argument("--force", action="store_true")
    p.add_argument("--timeout", type=int, default=300)
    p.add_argument("--workers", type=int, default=1)
    p.add_argument("--ranges")
    p.add_argument("--geo")
    p.set_defaults(func=cmd_all)

    args = parser.parse_args(argv)
    args.func(args)


if __name__ == "__main__":
    main()
