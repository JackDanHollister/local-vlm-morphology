"""Summary analytics over the built graph."""

from __future__ import annotations

import collections
import math

import networkx as nx
import numpy as np

from .graph import cosine_matrix, specimen_projection, zscore
from .locations import haversine_km


def mantel(feature_d: np.ndarray, geo_d: np.ndarray, permutations: int = 999, seed: int = 7) -> dict:
    n = feature_d.shape[0]
    iu = np.triu_indices(n, 1)
    a, b = feature_d[iu], geo_d[iu]
    if n < 4 or a.std() == 0 or b.std() == 0:
        return {"n": int(n), "r": None, "p": None, "note": "too few specimens or zero variance"}
    r = float(np.corrcoef(a, b)[0, 1])
    rng = np.random.default_rng(seed)
    count = 0
    for _ in range(permutations):
        perm = rng.permutation(n)
        rp = float(np.corrcoef(a, geo_d[np.ix_(perm, perm)][iu])[0, 1])
        if abs(rp) >= abs(r):
            count += 1
    return {"n": int(n), "r": round(r, 4), "p": round((count + 1) / (permutations + 1), 4),
            "permutations": permutations, "note": "Pearson correlation of descriptor distance vs geographic distance; two-sided permutation p"}


def report(G: nx.MultiDiGraph, locations: dict | None = None, *, mantel_enabled: bool = False, mantel_min_n: int = 8) -> dict:
    kinds = collections.Counter(d["kind"] for _, d in G.nodes(data=True))
    labels = collections.Counter(d["label"] for _, _, d in G.edges(data=True))
    P = specimen_projection(G)
    degree = dict(P.degree())
    components = [sorted(c) for c in nx.connected_components(P)] if P.number_of_nodes() else []
    isolates = sorted(nx.isolates(P))
    communities = []
    if P.number_of_edges():
        for group in nx.community.greedy_modularity_communities(P, weight="weight"):
            communities.append(sorted(group))
    colours = collections.defaultdict(list)
    for u, v, d in G.edges(data=True):
        if d["label"] == "shows colour":
            colours[v.split(":", 1)[1]].append(u.split(":", 1)[1])
    specimen_ids = G.graph.get("specimen_order", [])
    vectors = np.array([[np.nan if v is None else v for v in G.nodes["specimen:" + s]["descriptors"].values()] for s in specimen_ids], dtype=float) \
        if specimen_ids else np.zeros((0, 0))
    mantel_result = None
    loc_records = (locations or {}).get("records", {})
    located = [s for s in specimen_ids if s in loc_records and G.nodes["specimen:" + s].get("image_count", 0) > 0]
    if mantel_enabled and len(located) >= mantel_min_n:
        idx = [specimen_ids.index(s) for s in located]
        z = zscore(vectors[idx])
        feature_d = 1.0 - cosine_matrix(z)
        geo_d = np.array([[haversine_km(loc_records[a]["latitude"], loc_records[a]["longitude"], loc_records[b]["latitude"], loc_records[b]["longitude"]) for b in located] for a in located])
        mantel_result = mantel(feature_d, geo_d)
    elif mantel_enabled:
        mantel_result = {"n": len(located), "r": None, "p": None, "note": f"needs at least {mantel_min_n} specimens with both features and a location"}
    return {
        "nodes": G.number_of_nodes(), "edges": G.number_of_edges(),
        "node_kinds": dict(sorted(kinds.items())), "edge_labels": dict(sorted(labels.items())),
        "specimen_degree": {k.split(":", 1)[1]: v for k, v in sorted(degree.items())},
        "components": components, "communities": communities, "isolates": isolates,
        "projection": {"nodes": P.number_of_nodes(), "edges": P.number_of_edges(), "note": "undirected, weighted: similar to (cosine) + near (1/(1+km))"},
        "colour_membership": {k: sorted(v) for k, v in sorted(colours.items())},
        "located_specimens": len(G.graph.get("located", [])),
        "location_problems": (locations or {}).get("problems", []),
        "mantel": mantel_result,
    }


def report_markdown(summary: dict) -> str:
    lines = ["# Specimen feature graph report", "",
             f"Nodes: {summary['nodes']}  Edges: {summary['edges']}", "", "## Node kinds", ""]
    lines += [f"- {k}: {v}" for k, v in summary["node_kinds"].items()]
    lines += ["", "## Edge labels", ""] + [f"- {k}: {v}" for k, v in summary["edge_labels"].items()]
    lines += ["", "## Specimen communities (similarity + proximity)", ""]
    for i, group in enumerate(summary["communities"], 1):
        lines.append(f"- community {i}: " + ", ".join(g.split(':', 1)[1] for g in group))
    lines += ["", "## Colour membership", ""] + [f"- {k}: {', '.join(v)}" for k, v in summary["colour_membership"].items()]
    m = summary.get("mantel")
    lines += ["", "## Feature distance vs geographic distance", ""]
    if m and m.get("r") is not None:
        lines.append(f"Mantel r = {m['r']} (p = {m['p']}, n = {m['n']}, {m['permutations']} permutations)")
    else:
        lines.append("Not computed: " + ((m or {}).get("note") or "pass --mantel to run the exploratory test"))
    lines.append("")
    lines.append("All similarity, colour and proximity edges are exploratory descriptors of the images and coordinates supplied, not taxonomic or biological conclusions.")
    if summary.get("isolates"):
        lines += ["", "## Isolated specimens (no analysis edges)", ""] + [f"- {i.split(':', 1)[1]}" for i in summary["isolates"]]
    if summary["location_problems"]:
        lines += ["", "## Location file problems", ""] + [f"- {p}" for p in summary["location_problems"]]
    return "\n".join(lines) + "\n"
