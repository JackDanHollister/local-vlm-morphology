"""Fetch GB+IE occurrence points per species from GBIF and build:
  data/butterflies/gbif/<Genus_species>.json   raw points (lat, lon, year)
  data/butterflies/species_ranges.json         per-species point sample + 0.5 deg cells
  data/butterflies/locations.csv               one SIMULATED locality per sampled specimen,
                                                drawn at random from its species' occurrences.
The specimen localities are a possibility for the method demo, not the real
collection sites of the NHM specimens.
"""

import argparse
import csv
import json
import math
import random
import time
import urllib.parse
import urllib.request
from pathlib import Path

API = "https://api.gbif.org/v1"


def get(url, tries=4):
    for attempt in range(tries):
        try:
            with urllib.request.urlopen(url, timeout=60) as r:
                return json.load(r)
        except Exception as exc:
            if attempt == tries - 1:
                raise
            time.sleep(2 * (attempt + 1))


BACKBONE = "d7dddbf4-2cf0-4f39-9b2a-bb099caae36c"


def resolve(name):
    """Backbone match; on a higher-rank match fall back to species search and follow synonyms."""
    match = get(f"{API}/species/match?{urllib.parse.urlencode({'name': name, 'kingdom': 'Animalia'})}")
    if match.get("usageKey") and match.get("rank") in ("SPECIES", "SUBSPECIES"):
        return match.get("usageKey"), match
    search = get(f"{API}/species/search?{urllib.parse.urlencode({'q': name, 'rank': 'SPECIES', 'datasetKey': BACKBONE, 'limit': 10})}")
    for r in search.get("results", []):
        if (r.get("canonicalName") or "").lower() == name.lower():
            key = r.get("acceptedKey") or r.get("key")
            return key, {"usageKey": key, "scientificName": r.get("accepted") or r.get("scientificName"),
                         "matchType": "SEARCH_" + str(r.get("taxonomicStatus")), "status": r.get("taxonomicStatus"), "queried": name}
    return None, match


def fetch_species(name, limit_total):
    key, match = resolve(name)
    if not key:
        return {"name": name, "match": match, "points": []}
    points = []
    for country in ("GB", "IE"):
        offset = 0
        while offset < limit_total:
            q = urllib.parse.urlencode({"taxonKey": key, "country": country, "hasCoordinate": "true",
                                        "hasGeospatialIssue": "false", "limit": 300, "offset": offset})
            page = get(f"{API}/occurrence/search?{q}")
            for r in page.get("results", []):
                lat, lon = r.get("decimalLatitude"), r.get("decimalLongitude")
                if lat is None or lon is None:
                    continue
                points.append([round(lat, 4), round(lon, 4), r.get("year"), country])
            offset += 300
            if page.get("endOfRecords", True):
                break
    return {"name": name, "match": {k: match.get(k) for k in ("usageKey", "scientificName", "matchType", "status")}, "points": points}


def cell(lat, lon, size):
    return f"{math.floor(lat / size) * size:g},{math.floor(lon / size) * size:g}"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--manifest", default="data/butterflies/specimens.csv")
    ap.add_argument("--out", default="data/butterflies")
    ap.add_argument("--per-species", type=int, default=1200, help="max occurrences per species per country")
    ap.add_argument("--cell", type=float, default=0.5)
    ap.add_argument("--seed", type=int, default=7)
    ap.add_argument("--species-root", help="derive species list from folder names instead of the manifest")
    args = ap.parse_args()
    out = Path(args.out)
    gbif_dir = out / "gbif"
    gbif_dir.mkdir(parents=True, exist_ok=True)
    if args.species_root:
        species = sorted(p.name for p in Path(args.species_root).iterdir() if p.is_dir() and not p.name.startswith("."))
    else:
        with open(args.manifest, newline="") as fh:
            species = sorted({r["species"] for r in csv.DictReader(fh)})
    ranges = {}
    for i, sp in enumerate(species, 1):
        path = gbif_dir / f"{sp}.json"
        if path.exists():
            data = json.loads(path.read_text())
        else:
            data = fetch_species(sp.replace("_", " "), args.per_species)
            path.write_text(json.dumps(data))
        pts = data["points"]
        cells = sorted({cell(p[0], p[1], args.cell) for p in pts})
        rng = random.Random(args.seed + i)
        sample = rng.sample(pts, min(400, len(pts)))
        ranges[sp] = {"gbif": data["match"], "occurrences": len(pts), "cells": cells, "cell_degrees": args.cell,
                      "sample_points": [[p[0], p[1]] for p in sample]}
        print(f"{i:2d}/{len(species)} {sp:28s} {len(pts):5d} pts {len(cells):3d} cells  {data['match'].get('scientificName')}", flush=True)
    (out / "species_ranges.json").write_text(json.dumps({"schema": "species-ranges-v1", "source": "GBIF occurrence API, GB+IE, hasCoordinate, no geospatial issues",
                                                          "cell_degrees": args.cell, "species": ranges}))
    if not args.species_root:
        rng = random.Random(args.seed)
        with open(args.manifest, newline="") as fh:
            rows = list(csv.DictReader(fh))
        with open(out / "locations.csv", "w", newline="") as fh:
            w = csv.writer(fh)
            w.writerow(["specimen_id", "latitude", "longitude", "locality", "country", "collected_date", "site_id", "locality_basis"])
            for r in rows:
                pts = json.loads((gbif_dir / f"{r['species']}.json").read_text())["points"]
                if not pts:
                    continue
                lat, lon, year, cc = rng.choice(pts)
                w.writerow([r["specimen_id"], lat, lon, f"simulated point in {r['species'].replace('_', ' ')} range",
                            "United Kingdom" if cc == "GB" else "Ireland", year or "", r["species"],
                            "SIMULATED: random GBIF occurrence of the species, not the specimen's real collection site"])
        print("locations.csv written")


if __name__ == "__main__":
    main()
