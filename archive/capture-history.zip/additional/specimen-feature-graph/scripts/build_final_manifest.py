"""Finalise the butterfly subset at N per species.

Preference order per species: specimens already registered in the store (so
existing model runs are kept), then images already on disk (sorted), then
fresh seeded picks copied from the source with retries. Surplus images move to
images_unused/. Writes specimens.csv.
"""

import argparse
import csv
import json
import random
import shutil
import sys
import time
from pathlib import Path

SUFFIXES = {".jpg", ".jpeg", ".png"}


def copy_retry(src, dest, tries=3):
    for attempt in range(tries):
        tmp = dest.with_suffix(dest.suffix + ".part")
        try:
            shutil.copyfile(src, tmp)
            tmp.replace(dest)
            return True
        except OSError as exc:
            print(f"retry {attempt+1} {src.name}: {exc}", file=sys.stderr, flush=True)
            tmp.unlink(missing_ok=True)
            time.sleep(3)
    return False


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("root")
    ap.add_argument("--out", default="data/butterflies")
    ap.add_argument("--store", default="store_butterflies")
    ap.add_argument("--per-species", type=int, default=10)
    ap.add_argument("--seed", type=int, default=7)
    args = ap.parse_args()
    root, out = Path(args.root), Path(args.out)
    images, unused = out / "images", out / "images_unused"
    unused.mkdir(exist_ok=True)
    index = json.loads((Path(args.store) / "index.json").read_text())
    in_store = {}
    for sid, rec in index["specimens"].items():
        sp = rec.get("extra", {}).get("species")
        if sp and any(i["specimen_id"] == sid for i in index["images"].values()):
            in_store.setdefault(sp, []).append(sid)
    on_disk = {}
    for p in sorted(images.iterdir()):
        if p.suffix.lower() in SUFFIXES and "__" in p.stem:
            sp, barcode = p.stem.split("__", 1)
            on_disk.setdefault(sp, {})[barcode] = p
    rows, kept = [], set()
    species_dirs = sorted(p for p in root.iterdir() if p.is_dir() and not p.name.startswith("."))
    for folder in species_dirs:
        sp = folder.name
        chosen = []
        for sid in sorted(in_store.get(sp, [])):
            if sid in on_disk.get(sp, {}) and len(chosen) < args.per_species:
                chosen.append(sid)
        for sid in sorted(on_disk.get(sp, {})):
            if sid not in chosen and len(chosen) < args.per_species:
                chosen.append(sid)
        if len(chosen) < args.per_species:
            rng = random.Random(f"{args.seed}:{sp}")
            files = sorted(p for p in folder.iterdir() if p.suffix.lower() in {".jpg", ".jpeg", ".png", ".tif", ".tiff"})
            rng.shuffle(files)
            for src in files:
                if len(chosen) >= args.per_species:
                    break
                barcode = "_".join(src.stem.split("_")[:2]) if src.stem.startswith("BMNHE_") else src.stem[:24]
                if barcode in chosen:
                    continue
                dest = images / f"{sp}__{barcode}{src.suffix.lower()}"
                if dest.exists() or copy_retry(src, dest):
                    on_disk.setdefault(sp, {})[barcode] = dest
                    chosen.append(barcode)
                    print(f"copied {dest.name}", file=sys.stderr, flush=True)
        genus = sp.split("_")[0]
        for sid in chosen:
            path = on_disk[sp][sid]
            kept.add(path.name)
            rows.append({"image": path.name, "specimen_id": sid, "label": f"{sp.replace('_', ' ')} {sid}",
                         "view": "dorsal", "species": sp, "genus": genus})
        print(f"{sp}: {len(chosen)} ({len(in_store.get(sp, []))} from store)", file=sys.stderr, flush=True)
    moved = 0
    for p in list(images.iterdir()):
        if p.is_file() and p.name not in kept and not p.name.startswith("."):
            shutil.move(str(p), unused / p.name)
            moved += 1
    with open(out / "specimens.csv", "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)
    print(f"{len(rows)} specimens across {len(species_dirs)} species; {moved} surplus images moved to images_unused/")


if __name__ == "__main__":
    main()
