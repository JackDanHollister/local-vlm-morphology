"""Build specimens.csv from sampled filenames <Genus_species>__<barcode>.<ext>."""
import csv
import sys
from pathlib import Path

images = Path(sys.argv[1])
out = Path(sys.argv[2])
rows = []
for p in sorted(images.iterdir()):
    if p.suffix.lower() not in {".jpg", ".jpeg", ".png"} or "__" not in p.stem:
        continue
    species, barcode = p.stem.split("__", 1)
    genus = species.split("_")[0]
    rows.append({"image": p.name, "specimen_id": barcode, "label": f"{species.replace('_', ' ')} {barcode}",
                 "view": "dorsal", "species": species, "genus": genus})
with open(out, "w", newline="") as fh:
    w = csv.DictWriter(fh, fieldnames=list(rows[0]))
    w.writeheader()
    w.writerows(rows)
print(f"{len(rows)} rows -> {out}")
