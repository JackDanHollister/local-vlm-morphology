"""Sample N images per species folder into a flat image dir with a manifest.

Source layout: <root>/<Genus_species>/BMNHE_<barcode>_<id>_<hash>.JPG
Output: <out>/images/<Genus_species>__BMNHE_<barcode>.JPG and <out>/specimens.csv
(image, specimen_id, label, view, species, genus, source_file).
"""

import argparse
import csv
import random
import shutil
import sys
import time
from pathlib import Path

SUFFIXES = {".jpg", ".jpeg", ".png", ".tif", ".tiff"}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("root")
    ap.add_argument("--out", required=True)
    ap.add_argument("--per-species", type=int, default=10)
    ap.add_argument("--seed", type=int, default=7)
    args = ap.parse_args()
    rng = random.Random(args.seed)
    root, out = Path(args.root), Path(args.out)
    images = out / "images"
    images.mkdir(parents=True, exist_ok=True)
    rows = []
    for folder in sorted(p for p in root.iterdir() if p.is_dir() and not p.name.startswith(".")):
        files = sorted(p for p in folder.iterdir() if p.suffix.lower() in SUFFIXES)
        chosen = rng.sample(files, min(args.per_species, len(files)))
        spare = [f for f in files if f not in chosen]
        rng.shuffle(spare)
        for src in chosen:
            while True:
                barcode = "_".join(src.stem.split("_")[:2]) if src.stem.startswith("BMNHE_") else src.stem[:24]
                dest = images / f"{folder.name}__{barcode}{src.suffix.lower()}"
                if dest.exists() and dest.stat().st_size > 0:
                    break
                ok = False
                for attempt in range(3):
                    tmp = dest.with_suffix(dest.suffix + ".part")
                    try:
                        shutil.copyfile(src, tmp)
                        tmp.replace(dest)
                        ok = True
                        break
                    except OSError as exc:
                        print(f"retry {attempt+1} {src.name}: {exc}", file=sys.stderr, flush=True)
                        tmp.unlink(missing_ok=True)
                        time.sleep(3)
                if ok or not spare:
                    break
                src = spare.pop()  # substitute another file from the same species
                print(f"substituted {src.name}", file=sys.stderr, flush=True)
            specimen_id = barcode
            genus, _, species = folder.name.partition("_")
            rows.append({"image": dest.name, "specimen_id": specimen_id, "label": f"{folder.name.replace('_', ' ')} {barcode}",
                         "view": "dorsal", "species": folder.name, "genus": genus, "source_file": str(src)})
    with open(out / "specimens.csv", "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)
    print(f"{len(rows)} images from {len({r['species'] for r in rows})} species -> {out}")


if __name__ == "__main__":
    main()
