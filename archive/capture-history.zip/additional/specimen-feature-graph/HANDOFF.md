# Butterfly feature graph handoff

Snapshot transferred on 14 October 2026 from The Magi specimen-feature-graph
project. This is an additional cross-specimen experiment alongside the existing
TraitTrail Capture scanner datasets.

## Open the finished graph

Open `outputs_butterflies/viewer.html` in a browser after cloning or pulling this
repository. The viewer is self-contained, including thumbnail images, graph data
and its offline map; no server, model account or API key is needed.

The saved graph contains 590 specimens from 59 British butterfly species,
17,637 nodes and 86,194 edges. Colour, trait and species filters link specimen
images to the graph and map. Locations are **simulated** samples from GBIF
species ranges, not verified collection localities. Saved model observations
are research outputs, not expert-confirmed annotations.

## Included material

- `data/butterflies/`: selected images, unused complete images, manifests,
  GBIF source responses, species ranges, simulated locations and processing logs.
- `store_butterflies/`: immutable image assets, measured features, observation
  records, raw model responses, prompts, run logs and retained failed attempts.
- `outputs_butterflies/`: viewer, graph JSON/JSON-LD/GraphML/GEXF, CSV exports,
  specimen projection and graph analysis reports.
- `specimen_graph/`, `scripts/`, `config/`, `tests/`: pipeline and validation.
- `data/`, `store/`, `outputs/`: original synthetic demo and supporting map data.
- `README.md`, `CHANGELOG.md`: original project documentation and history.
- `TRANSFER_MANIFEST.json`: SHA-256 checksums of transferred source files.

Local consultation records, Python caches and one incomplete `.part` image
were omitted. The full approximately 110,000-image source archive was outside
this project and is not included. Historical absolute source paths remain in
saved evidence; working assets use paths relative to their store directory.
The nested `.gitignore` permits the frozen datasets to be tracked here.

## Continue on another computer

From the repository root:

```bash
cd additional/specimen-feature-graph
python3 -m venv .venv
# macOS/Linux:
source .venv/bin/activate
# Windows PowerShell alternative: .venv/Scripts/Activate.ps1
python -m pip install -r requirements.txt
python -m pytest -q tests
```

Rebuild graph exports from the saved evidence, without running a model:

```bash
python -m specimen_graph --store store_butterflies graph --out outputs_butterflies --ranges data/butterflies/species_ranges.json --mantel
```

See `README.md` for ingestion and optional new observations. Run subsequent
analysis in a copy or a new output directory if preserving this snapshot.

## Validation at transfer

All 24 pipeline tests passed. Transferred assets and graph counts were checked,
and source files were checksum-verified. No model calls or new observations
were made during transfer.
