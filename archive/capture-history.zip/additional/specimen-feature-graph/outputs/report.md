# Specimen feature graph report

Nodes: 67  Edges: 136

## Node kinds

- colour: 9
- image: 18
- location: 12
- region: 7
- shape_class: 3
- site: 4
- specimen: 14

## Edge labels

- collected at: 12
- depicted in: 18
- has shape class: 13
- near: 10
- near duplicate: 1
- shows colour: 28
- similar to: 26
- within: 28

## Specimen communities (similarity + proximity)

- community 1: demo03, demo05, demo07, demo09, demo11
- community 2: demo02, demo06, demo10
- community 3: demo04, demo08, demo12
- community 4: demo01, demo_dup, demo_empty

## Colour membership

- black: demo02, demo03, demo04, demo06, demo07, demo08, demo09, demo10, demo11, demo12
- blue: demo07
- brown: demo01, demo04, demo05, demo08, demo09, demo12, demo_dup
- green: demo03
- grey: demo02, demo06, demo10
- orange: demo08, demo12
- purple: demo11
- white: demo10, demo_empty
- yellow: demo04

## Feature distance vs geographic distance

Mantel r = 0.3568 (p = 0.008, n = 12, 999 permutations)

All similarity, colour and proximity edges are exploratory descriptors of the images and coordinates supplied, not taxonomic or biological conclusions.

## Location file problems

- line 14: latitude 'not-a-number' is not a number
