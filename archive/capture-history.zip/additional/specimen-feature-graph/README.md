# Specimen Feature Graph

## Overview
Build a graph network from a set of 2D specimen images (one or more images per
specimen, all different specimens) plus collection-location data. Image
features are extracted two ways: deterministic classical descriptors (colour,
shape, texture, perceptual hash) that need no model, and optional structured
visual observations from a vision-language model using the same
`specimen-features-v1` vocabulary as `openscan-specimen-lab`. Locations are
loaded from a CSV and become location, site and region nodes. Everything is
linked in one evidence graph and exported as graph JSON (compatible with the
openscan-specimen-lab viewer format), JSON-LD, GraphML, GEXF, CSV and a
self-contained offline HTML viewer.

Reference codebase: https://github.com/JackDanHollister/openscan-specimen-lab
(private). That repo handles one specimen scanned from 40 views and keeps every
scan as a separate graph; this project is the cross-specimen counterpart, where
many specimens share one graph and features and locations connect them.

## Current Status
Active. Small butterfly version complete (2026-09-15): 59 British species x 10
NHM specimens = 590, all with validated Claude CLI observations, measured
colours, simulated GBIF-range localities and species range cells, built into
`outputs_butterflies/` with the offline linked graph + map viewer. Awaiting
Jack's review before scaling to the full ~110k crops (use the source zip).

## Objectives
- Ingest arbitrary 2D specimen images with content-hashed, immutable assets.
- Extract model-free image features per image and aggregate per specimen.
- Optionally collect structured VLM observations (Claude CLI first) using the
  openscan `specimen-features-v1` contract, validated before use.
- Load location data (lat/lon, locality, country, date) and derive site and
  region groupings plus pairwise geographic distances.
- Build one graph: specimen, image, feature, observation, colour, location,
  site, region and model-run nodes with typed edges, including feature
  similarity (kNN) and geographic proximity edges.
- Export the graph in several formats and provide an offline HTML viewer.
- Report basic graph analytics: components, degree, communities, and a
  feature-distance vs geo-distance permutation (Mantel) test.

## Plan / Next Steps
- [x] Read openscan-specimen-lab (contract, store, providers, graph export).
- [x] Scaffold project files and conda env.
- [x] Core package: store, features, locations, graph, exports, viewer, CLI.
- [x] Synthetic demo data generator and end-to-end test.
- [x] Butterfly subset: 10 per species, manifest, GBIF ranges, simulated localities.
- [x] VLM observation runs (Claude CLI, sonnet) on all 590 with revalidation.
- [x] Linked graph + offline map viewer with colour/trait/species filters.
- [ ] Jack reviews the small version; tune layout/filters as requested.
- [ ] Scale up: unpack `1butt_bbox_cut_minus_1_orig.zip` locally, sample or
      run all species; consider a cheaper VLM tier for ~110k images.
- [ ] Decide whether this becomes its own GitHub repo.

## Usage

```bash
conda activate specimen-feature-graph          # or nhm-specimen-counter as fallback
cd projects/specimen-feature-graph

# put images in data/images/  (specimen ID = filename stem, or part before "__")
python -m specimen_graph locations --template data/locations.csv   # fill this in
python -m specimen_graph all --images data/images --locations data/locations.csv --mantel
open outputs/viewer.html

# step by step
python -m specimen_graph ingest --images data/images [--manifest data/specimens.csv]
python -m specimen_graph features
python -m specimen_graph locations --csv data/locations.csv
python -m specimen_graph observe --provider claude        # optional VLM pass
python -m specimen_graph graph --mantel [--coarsen 2]     # rebuild exports

# synthetic end-to-end check
python -m specimen_graph demo && python -m specimen_graph all --images data/demo/images --locations data/demo/locations.csv --mantel
python -m pytest -q tests
```

Graph tuning lives in `config/graph.json` (kNN k and mode, proximity radius,
grid size, duplicate threshold, descriptor family weights, coordinate
coarsening for shareable exports).

## Butterfly subset (current run)

Source: `~/Documents/academic/phd_chapters/chapter_3/1butt_bbox_cut_minus_1_orig 2/`
(58 British butterfly species folders, ~110k NHM crops, `BMNHE_<barcode>_...JPG`).

```bash
# 10 random specimens per species -> data/butterflies/{images,specimens.csv}
python scripts/sample_species_folders.py "<source root>" --out data/butterflies --per-species 10
# GBIF GB+IE occurrences per species -> gbif/*.json, species_ranges.json, and a
# SIMULATED locations.csv (one random GBIF point of the species per specimen)
python scripts/fetch_gbif_ranges.py --manifest data/butterflies/specimens.csv --out data/butterflies
python -m specimen_graph --store store_butterflies ingest --images data/butterflies/images --manifest data/butterflies/specimens.csv
python -m specimen_graph --store store_butterflies features
python -m specimen_graph --store store_butterflies locations --csv data/butterflies/locations.csv
python -m specimen_graph --store store_butterflies observe --provider claude --workers 5
python -m specimen_graph --store store_butterflies graph --out outputs_butterflies --ranges data/butterflies/species_ranges.json --mantel
open outputs_butterflies/viewer.html
```

The observation vocabulary is the openscan `specimen-features-v1` set plus a
Lepidoptera extension (eyespots present/count, wing margin pattern, hindwing
tails, dorsal/ventral surface, forewing apex marking, primary/secondary/
tertiary wing colour). Measured colours link the top three k-means colours per
specimen. Specimen localities are simulated draws from the species' GBIF range
and are labelled as such on every location record; species range cells (0.5°)
come from the same GBIF points. The viewer has colour, trait and species
filters that highlight specimens in both the graph and the offline map.

## Technical Details
- Python 3.11, conda env `specimen-feature-graph` (fallback env with the same
  deps: `nhm-specimen-counter`).
- Dependencies: Pillow, numpy, networkx, jsonschema, scipy (optional), pytest.
- Package: `specimen_graph/` with CLI `python -m specimen_graph`.
- Data layout (all git-ignored except config):
  - `data/images/` input images. Specimen ID is the filename stem, or the
    part before `__` when several views share a specimen
    (`beetle07__dorsal.jpg`). A `data/specimens.csv` manifest overrides this.
  - `data/locations.csv` columns: `specimen_id, latitude, longitude,
    locality, country, collected_date, site_id` (extra columns are kept).
  - `store/` content-hashed assets, image records, feature records, model runs
    (`store_butterflies/` for the butterfly subset).
  - `outputs/` graph exports, viewer HTML and reports (`outputs_butterflies/`).
  - `data/geo/british_isles_outline.json` Natural Earth 50m outline embedded in
    the offline map.
- Graph JSON format mirrors openscan-specimen-lab: nodes `{id, label, kind,
  record, ...}`, edges `{id, source, target, label}`.

## GitHub
Not yet created. Magi-managed for now; images and store are ignored.
