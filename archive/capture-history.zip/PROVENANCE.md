# Source and evidence provenance

The `capture/` tree preserves the operating code assembled on 12 October 2026.
The `saved-demo/` tree preserves published `openscan-specimen-lab` commit
`e5732e0283fdeaa83fa67ced3860ef5009ab128d`, including its five immutable scan
bundles. The original repository remains at
https://github.com/JackDanHollister/openscan-specimen-lab.

`provenance/conference-candidate-manifest.json` describes the original local
conference snapshot and its 1,846 declared files, with per-file SHA-256 and
origins. Its root `README.md` was relocated without content changes to
`docs/conference-candidate.md`; its original citation file is preserved at
`provenance/CITATION.conference-candidate.cff`. The `capture/` and `saved-demo/`
trees retain their manifest hashes. The root citation now points to this
independent repository. The repository adds this overview, Git ignore
rules, a changelog and GitHub CI. The manifest describes the frozen source
candidate, not these later repository documentation files.

`provenance/conference-archive.json` records the corresponding local ZIP hash.
The ZIP is retained locally rather than duplicated as a large repository file.
`provenance/offline-validation.json` records 98 operating-source tests, 104
portable tests, five restored-bundle audits and archive integrity validation.

The raw prompts/responses, failed batches, image bytes and per-scan graphs are
preserved. All five bundled scans use Codex/gpt-6-astra. Qwen experiment evidence
and the publication manuscript remain separate pending the final evidence
selection. The capture calibration is historical for the original rig.
