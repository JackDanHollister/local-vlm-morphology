# Changelog — TraitTrail Capture

## 2026-10-12 — Initial independent source companion

- Separated the physical scanner/TDWG project from TraitTrail Studio.
- Preserved operating source and portable saved-demo source in independent trees.
- Included five immutable scan datasets, original model outputs and graph exports.
- Added source provenance, draft citation metadata and GitHub offline validation.
- Updated the root citation link to the independent TraitTrail Capture repository; the original conference-candidate citation remains in provenance.
- Retained the existing openscan-specimen-lab baseline repository. Final conference evidence, licences and DOI are pending.

## 2026-10-12 — Research companion structure

- Reframed the front page around the TDWG study, author details, methods and example evidence, following the structure of the author's other paper archives.
- Added project breakdown, observation scheme, data guide, evidence limitations and explicit incomplete status.
- Added a reproducible scan-record summary. Preserved hardware and replay source/data are unchanged; TraitTrail Studio remains a separate software project.
## 2026-10-14 — Butterfly cross-specimen graph handoff

- Added the existing specimen-feature-graph experiment under `additional/`, including images, measured features, saved observations and run evidence, geographic inputs, exports and offline viewer.
- Added other-computer setup/rebuild instructions and a source checksum manifest; documented simulated localities and the separate scanner-data boundary.
- Preserved the original pipeline and demo, omitting consultation records, caches and an incomplete image download.
- Validation: 24 pipeline tests passed; asset availability, graph counts and transferred checksums verified.

## 2026-10-14 — Hackathon workspace onboarding

- Cloned the standalone repository into The Magi Home Edition workspace and registered it in the parent project roster; excluded the checkout from the parent repository.
- Read the research overview, method, observation contract, limitations, completion checklist and existing history.
- Added the 14–15 October hackathon context and next steps; read the shared MAS opening slides and recorded the DiSSCo sandbox, openDS annotation and RabbitMQ integration goals. TraitTrail service scope remains to be selected.
- Validation: 98 capture tests and 104 saved-demo tests passed; all five scan bundles restored and passed evidence audits; saved-data summary matched documented counts.
- No scanner actions, new model runs, commits or pushes.
- Agent: Codex

## 2026-10-14 — Three-provider MAS plan

- Recorded the proposed two-day software-only MAS plan in README: OpenRouter, network GB10 and workstation VLM profiles, one annotation contract, DiSSCo integration and portable setup.
- Inspected the existing OpenAI-compatible observer and local hardware/lab documentation; current backend availability and compatibility remain to be tested.
- Identified official DiSSCo MAS developer documentation and recorded schema/template, network access and hosted-budget decisions needed before implementation.
- Validation: documentation diff checked; no code changes or model requests.
- Agent: Codex

## 2026-10-14 — DiSSCo format and graph integration review

- Reviewed official MAS guides, annotation submission/target/body schemas, assertions, entity relationships and the linked template.
- Documented image-region mapping, graph export/link options, crop-coordinate and identifier requirements, and sandbox/deployment questions in the project breakdown.
- Found Kafka/jobID versus RabbitMQ/jobId drift and template creator fields incompatible with current assertion/relationship schemas.
- Clarified deployment-level inference configuration; per-user DiSSCover API keys are not established by the reviewed guide.
- Validated four illustrative schema components and confirmed rejection of a stale template assertion field; full event/sandbox validation remains outstanding.
- Awaiting laptop graph additions before implementation. No code changes, inference, commits or pushes.
- Agent: Codex

## 2026-10-14 — User-hosted inference architecture clarification

- Narrowed the current scope to MAS development; deferred TraitTrail graph application work while retaining evidence export requirements.
- Confirmed the documented DiSSCo-hosted middleware/external API value-service split and static outbound IP allowlisting option.
- Distinguished local validation from live user-local worker support; no self-service worker or per-user model key mechanism was found in reviewed guides.
- Recorded a proposed workstation value service with GB10, workstation and OpenRouter profiles; live connectivity requires organiser agreement.
- Validation: documentation diff checked. No code, network configuration, inference, commits or pushes.
- Agent: Codex

## 2026-10-14 — Supplied DiSSCo and BDQ reference review

- Reviewed the supplied DiSSCo demo repository main branch; found its current RabbitMQ template and compatible shared annotation helpers.
- Identified TaxaMorph's external ngrok inference call as concrete precedent for the user-equipment API arrangement; did not verify live deployment.
- Reviewed TDWG's BDQ draft, Rukaya's FastAPI/Java service and FilteredPush library organisation; separated metadata checking from specimen-image observations.
- A read-only Cloud Run root request timed out; availability remains unconfirmed. No data submission, email action or paid inference occurred.
- Updated implementation references and documented adaptation caveats. Documentation diff checked; no code changes, commits or pushes.
- Agent: Codex

## 2026-10-14 — Per-user local execution documentation audit

- Corrected product intent: every adopter runs their own observation service; Jack's computer is only the initial instance.
- Rechecked public documentation and inspected core job models and orchestration registration/deployment source.
- Found no per-job endpoint/key in the inspected models; registration documents admin rights, and TaxaMorph uses one fixed external endpoint.
- Recorded the distinction between supported external API access and unconfirmed per-user desktop routing, with candidate integration options for organiser discussion.
- Validation: documentation diff checked; read-only source review, no code or network changes, commits or pushes.
- Agent: Codex

## 2026-10-14 — Heavier MAS hosting comparison

- Compared LeafMachine, organ segmentation, VoucherVision, TaxaMorph and older embedded plant detection source/container definitions.
- Recorded external institutional/cloud inference versus embedded model packaging; live availability and DiSSCo GPU allocation were not verified.
- Documentation diff checked; no code changes, deployment, inference, commits or pushes.
- Agent: Codex

## 2026-10-14 — Guide reread and API-funded deployment options

- Recorded organiser confirmation that user-owned compute has no current protocol, plus their restricted-demo/tombstone/secret-removal offer.
- Rechecked official MAS guide sections for deployment secrets and job configuration.
- Proposed a lightweight DiSSCo MAS directly calling OpenRouter for the sandbox demo, avoiding a workstation tunnel for the hosted-API path; deployment remains unapproved/unperformed.
- Separated hackathon service credentials from a future personal image/key app and retained PC/GB10 demonstration options.
- Documentation diff checked; no code, inference, secret transfer, commits or pushes.
- Agent: Codex

## 2026-10-14 — GB10 observation value service running

- Fast-forwarded laptop additions to 87df8f2 while preserving local project notes; butterfly graph material is now available for later review.
- Verified GB10 access, installed vision model and existing Python dependencies. Deployed only software observer source and one sample image at /data/workspace/traittrail-mas; no weights downloaded.
- Added a loopback-only HTTP image observation service, submission client and configurable launch profile in mas/. Reused saved-demo observer/store; scanner source unchanged.
- Added request-level reasoning control and clarified total-count instance evidence. Two real-image attempts failed validation and remain retained; the corrected third request produced 16 accepted observations in 126.049 seconds using qwen3.8:27b-mtp-q8_0.
- Successful request fb521dc34ce54a8fbb23958ff43f34a5 / run_517a20489a604ff5 passed the GB10 evidence audit. Raw model output remains biologically unreviewed.
- Service listens on GB10 loopback 8766; workstation uses SSH forward 18766. View-only results are available through forwarded 8767. No public endpoint, paid model call, DiSSCo registration or annotation submission.
- Validation: eight new service/provider tests and 104 saved-demo tests pass; live HTTP health/invalid-upload/origin checks pass; viewer API and browser show the accepted run; compilation, launcher syntax and diff checks pass.
- Documented setup and current session-process lifecycle. No commits or pushes.
- Agent: Codex

## 2026-10-14 — GBIF specimen images and laptop graph inspection

- Downloaded two GBIF-linked Aglais io preserved-specimen images at 1600×1066, with separate media licence (CC BY 4.0), attribution, URLs, dimensions and hashes retained outside Git.
- Analysed occurrence 2234225450 through the GB10 API: 16 accepted observations in 96.003 seconds, evidence audit passed. Second image downloaded but not yet analysed.
- Opened separate live GBIF result viewer on forwarded port 8769, retaining the beetle viewer on 8767.
- Verified all 8,555 laptop transfer files against the manifest; inspected its offline butterfly graph and served it locally on loopback port 8768. Historical Claude outputs and simulated localities remain distinct from new Qwen results.
- Checked existing close-up material: low-resolution NHM specimen crops and larger scanner crops; identified butterfly-specific contract additions for future use.
- Validation: image decoding/hashes, live observation validation/audit, browser graph load and 21 Python syntax checks passed. Graph tests could not collect due to missing networkx; unavailable venv bootstrap prevented isolated setup. No system installation or graph source/data changes.
- No commits or pushes.
- Agent: Codex

## 2026-10-14 — DiSSCo MAS wrapper implemented

- Added media-job runner/RabbitMQ consumer, bounded HTTPS image retrieval, annotation mapping, configurable API bearer authentication, environment template and wrapper container/CI packaging.
- Pinned seven official openDS 0.4.0 submission schemas with checksums for offline validation. Predictions map conservatively to media comments with ROI selectors, complete grouped evidence, stable observation IDs and unreviewed model provenance.
- Rejected unsupported batching/private media URLs; tested malformed input, invalid predictions, failed jobs, secret-safe error messages and publish-before-ack behaviour. Live RabbitMQ credentials remain unavailable; transport tests use a simulated channel.
- Built the wrapper Docker image on GB10 ARM64 and ran a real end-to-end container job: fetched GBIF image, called GB10 Qwen, returned 20 schema-valid annotations; new request d4a94d9910f94e7dba6c461a01c0710c passed its evidence audit.
- Rebuilt final mapping and validated recorded live outputs inside the container with networking disabled. Retained test outputs outside Git; all target/service IDs in those events are clearly local fixtures.
- Installed wrapper dependencies in an isolated GB10 environment and restarted the loopback value service using it. No weights downloaded or other model-service defaults changed.
- Validation: 19 MAS/service tests pass; container builds, live source/inference flow, evidence audit, offline full-schema validation, compilation and diff checks pass. GitHub CI and live sandbox/broker acceptance remain untested.
- Prepared deployment instructions and organiser configuration checklist. No public tunnel, secret transfer, DiSSCo registration/submission, commits or pushes.
- Agent: Codex

## 2026-10-14 — Ten-image demonstration set with damage candidate

- Selected two existing high-resolution GBIF specimens, seven NHM butterfly crops and one scanner crop; retained original bytes/source collections.
- Included apparent wing-loss specimen BMNHE_1387525, ambiguous appendage example and naturally jagged comma-butterfly margins; labels remain provisional and separate from inference prompts.
- Created a source/hash/attribution manifest and contact-sheet preview under ignored mas/runs/demo-set; copied all ten images and manifest to the GB10 demo-set directory.
- Validation: ten unique selections, image decoding and byte-for-byte SHA-256 equality checked; contact sheet visually inspected. No new inference, code changes, commits or pushes.
- Agent: Codex

## 2026-10-14 — Corrected TDWG image source and upstream submission preparation

- Owner identified openscan-specimen-lab as the intended image source. Inspected its current catalogue and preserved scan imagery rather than continuing the laptop butterfly selection.
- Selected ten archived crops (two per scan), including shell/applicability case and apparent fragmentary beetle in scan 5 pending owner confirmation. Preserved source hashes and crop provenance; copied corrected set to GB10 without overwriting prior selections.
- Prepared a self-contained service folder/workflow in a separately ignored clone of the supplied DiSSCo repository on local traittrail-mas; no commits, pushes or PR.
- Validation: ten crop copies matched archive SHA-256, contact sheet visually inspected, 10 packaged wrapper tests pass, diff checked. No model calls or source evidence changes.
- Agent: Codex

## 2026-10-14 — MAS registration details prepared

- Prepared service name/description, insect-media filter scope, deployment variable names and secure-token handoff requirements for the organisers.
- Rechecked requested latest annotation request schema: identical to pinned 0.4.0. Full 20-annotation sample event passes local schema validation.
- Public service URL/token/secure link, registered IDs and deployment are explicitly pending; developer ORCID was not found and is omitted rather than guessed.
- No messages sent, online validator uploads, secret transfers, commits or pushes.
- Agent: Codex

## 2026-10-14 — Developer ORCID verified

- Found Jack D. Hollister's ORCID 0000-0001-8697-5076 through the public ORCID API and verified matching limpet/mislabelled-specimen publications.
- Added it to the registration notes and revised message draft; no external message sent.
- Agent: Codex

## 2026-10-14 — Ngrok installation and authenticated API preparation

- Installed official ngrok 3.39.11 ARM64 binary on GB10 without system package changes.
- Generated an owner-only bearer-token file, copied it to an ignored owner-only workstation path, and restarted the local API with authentication. Missing/wrong tokens return 403; matching token returns 200; token values were not printed/shared.
- Added a tunnel launcher that refuses an unauthenticated API and disables HTTP inspection. Nineteen service/wrapper tests and launcher syntax checks pass.
- No ngrok agent/account configuration was found; dashboard sign-in is required and the user has been asked to complete it. Tunnel/public endpoint and secure-sharing link remain pending.
- No public exposure, secret transfer to third parties, commits or pushes.
- Agent: Codex

## 2026-10-14 — Authenticated public GB10 tunnel verified

- Configured existing ngrok account credential in owner-only GB10 configuration; removed temporary transfer copies. Started inspection-disabled tunnel to loopback observation API.
- Verified public HTTPS rejects missing/wrong bearer tokens (403) and accepts correct token (200). A public image request produced usable Qwen observations and its mapped annotation event passed schema validation. Results retained under ignored mas/runs/gbif with local fixture identifiers.
- Recorded public endpoint and shutdown/restart guidance in README. API token remains private; secure organiser sharing and real DiSSCo sandbox integration are pending.
- No commits, pushes or messages sent.
- Agent: Codex

## 2026-10-14 — Post-hackathon status review

- Owner confirmed the event is over. Summarised verified deliverables and remaining work in README, distinguishing local/container/schema success from unverified live DiSSCo acceptance.
- Read-only GB10 checks found authenticated observation API and inspection-disabled ngrok tunnel still running; cleanup is pending, no services stopped.
- Confirmed local hackathon changes and upstream submission folder/workflow remain uncommitted/untracked. No inference, tests, commits, pushes or external messages performed during this review.
- Agent: Codex

## 2026-10-14 — Demo tunnel stopped

- Stopped GB10 ngrok at the owner's request. Agent endpoint is offline and public URL returns HTTP 404 / ERR_NGROK_3200.
- Authenticated loopback observation API still returns HTTP 200. Existing model, results and credentials preserved for a future restart.
- No commits or pushes.
- Agent: Codex

## 2026-10-14 — Studio result compatibility verified

- Implemented saved-result viewer in the separate TraitTrail Studio checkout. Existing Capture API and annotation-event output open without changing MAS source or contract.
- Recorded integration status and scope; ngrok stays stopped. No commits or pushes.
- Agent: Codex

## [2026-10-15] — Shared mixed test selection

- Linked the new definitive TraitTrail test-images v1 selection, curated in Studio from existing archived scanner and butterfly files. Originals here remain unchanged.
- Owner confirmed taking scanner photographs and authorised public test-set publication, without a contact sheet. Butterfly media credits/licences verified per source record.
- No Capture service/scanner changes, model calls or repository pushes.

## [2026-10-15] — Protected endpoint restart and MAS handoff preparation

- Owner requested ngrok restart and preparation of organiser details/fork. Restarted the token-protected GB10 service and ngrok with inspection disabled; public anonymous access rejected and authenticated health passed.
- Fresh public Qwen request returned 16 validated observations; packaged mapping produced 20 schema-valid annotations. Downloaded latest request schema matches pinned 0.4.0. Saved artifacts in ignored mas/runs/readiness-2026-10-15.
- Created JackDanHollister/demo-enrichment-service-image fork and configured the local submission checkout with upstream/origin remotes. Fast-forwarded its existing traittrail-mas branch to current upstream main; staged only self-contained middleware plus workflow.
- Prepared secret-free example environment and organiser registration details. Tightened the submission validation test, formatted/linted package, and configured scoped lint/tests/container CI without registry secrets. No observation semantics/model settings changed.
- Validation: 19 worker/service and 10 package tests pass, scoped Ruff lint/format pass, container builds and network-disabled mapping reproduces 20 valid annotations. No real DiSSCo job submitted. Commit/push/PR permission requested separately; no API token exposed or shared.

## [2026-10-15] — Plain MAS branch name

- Renamed the local submission branch to `traittrail-mas` at the owner's request. Updated its workflow, registration record and documentation; recorded the preference for project branch names without assistant prefixes.
- Validation: branch/workflow/registration names agree and diff checks pass. No commits, pushes or PR creation.

## [2026-10-15] — Pre-publication MAS walkthrough

- Reviewed the prepared adapter, external service, vocabulary and retained inference/annotation example. Documented the one-image job flow, region-based annotation count, separate Studio review and current failed-job behaviour.
- Validation: reran all 10 submission-package tests successfully. No new inference, service/model changes, commits, pushes or PR creation.

## [2026-10-15] — MAS adapter published to fork

- Owner authorised commit/push and preparation of the registration answers for Sou. Committed only the 17 reviewed adapter/workflow files as `914e436` and pushed `traittrail-mas` to JackDanHollister/demo-enrichment-service-image. No other project source or credentials published; no upstream PR opened.
- Validation: 10 package tests pass; staged scope/credential checks and diff checks pass. Fork workflow 38714130015 passed lint, formatting, tests and Docker build. Protected endpoint recheck returned 403 anonymously and 200 with the private token; configured model unchanged.
- Slack is not connected. Owner chose to copy/send the message himself. Prepared all requested registration fields; API token remains in protected ignored files and secure transfer is pending. Real DiSSCo deployment/queue acceptance remain unverified.

## [2026-10-15] — Owner reports API token shared

- Jack confirmed he had already sent Sou the API token. Updated current registration notes and the local readiness record; recipient receipt/use and transfer method are unverified. No secret value read or recorded, and no message sent by the assistant.
- Prepared a brief reply about the upstream PR, container-publishing workflow and first sandbox test. Documentation-only update; diff checks pass.

## [2026-10-15] — DiSSCo pull request opened

- Owner explicitly requested opening the PR. Matched the current ruler-detection Public ECR pipeline and pinned actions, adding publication after passing checks only on upstream main. Proposed repository `public.ecr.aws/m8w1i6p4/traittrail-specimen-observation` needs team confirmation/provisioning. No registry credentials read or image published.
- Committed and pushed only the workflow/adapter README update as `190a217`; opened and attached DiSSCo/demo-enrichment-service-image PR #118, targeting main from JackDanHollister:traittrail-mas. It is open, ready for review and mergeable.
- Validation: 10 adapter tests, YAML parsing, publication gate checks across 18 contexts and diff checks passed. Updated fork CI 38716116185 passed lint, format, tests and Docker build; publication correctly skipped. Upstream run 38716174160 explicitly awaits maintainer approval, with no jobs run yet.
- Team review/merge, registry provisioning/publication, MAS registration and first live sandbox job remain pending. No model/service changes or new inference. API token already shared by the owner according to his report.

## [2026-10-15] — SonarCloud findings fixed in follow-up PR #120

- Investigated the ten reported issues: four dependency-installation vulnerabilities and six maintainability findings. Pinned all runtime/test transitive dependencies with 138 verified PyPI wheel hashes; CI/Docker require hashes and binary wheels. Refactored the validator into focused helpers, replaced duplicate keys with constants, removed redundant/empty code and corrected exception-test setup.
- Added meaningful semantic regression cases (22 tests total). Differential validation matches the original errors on 1,001 varied inputs and the retained live result; vocabulary, output schema, prompt, active service and model settings remain unchanged. No new inference or credentials accessed.
- Both locked installs and tests passed under isolated Python 3.12. Scoped Ruff and ARM64 Docker build passed; a network-disabled replay again produced 20 schema-valid annotations. Caught and fixed a folded-YAML formatting error in the initial update; the final workflow parses and its publication gate passes 18 contexts.
- Discovered Sou had approved/merged #118 as 6614ec1 while fixes were being prepared. Its upstream build and publication jobs succeeded. Created/pushed traittrail-quality-fixes (3c39d39) from updated upstream, opened/attached #120, and corrected #118's description to distinguish the later fixes.
- Final fork run 38717798506 and upstream run 38717864072 passed lint/format, locked install, 22 tests and Docker build. SonarCloud Code Analysis passed; quality gate OK with zero new issues, code smells or vulnerabilities. PR #120 is open/mergeable; its merge/publication and real MAS registration/job acceptance remain pending.

## [2026-10-15] — First sandbox failure investigated and diagnostics added

- Read the supplied public job/media records. TraitTrail MAS SANDBOX/SS6-GDM-NHR is registered/listed; job SANDBOX/0QN-TFL-A3X for media SANDBOX/387-C8S-B7X failed with MAS_EXCEPTION. Source JPEG download passes locally (1920×1282, 666,589 bytes). Public API health passes with the token and rejects anonymous access; the GB10 log shows no new inference request. Exact deployed failure remains unverified.
- The subsequent logger NameError job SANDBOX/1BL-715-45X references a different MAS/target. Found the undefined logger call in upstream apis-for-species-identification/main.py:127, with none in TraitTrail. Reported the distinction instead of changing the unrelated service.
- Added unbuffered stderr startup/configuration-presence and job-stage diagnostics, safe exception type/HTTP status and traceback locations. Logs exclude configuration values, request bodies/headers, URLs and raw exception strings. Existing failure/progress/acknowledgement behaviour unchanged. Added four diagnostics/privacy tests.
- Committed/pushed 9659034 to existing PR #120 and updated its description. All 26 tests pass under supported Python 3.12 with locked dependencies; Ruff, ARM64 Docker build and real container stderr/no-token-disclosure check pass. Updated fork CI 38722008052, upstream CI 38722014883 and SonarCloud pass. Workstation Python 3.14 passes the original 22 tests but its four logging-capture fixtures fail; Python 3.12 CI/container remains the supported target.
- No new inference, paid API calls, live sandbox scheduling, external messages, service restart or credentials changes. Team merge/redeployment of #120 and a correctly identified TraitTrail error/log are needed to finish the integration diagnosis.

## [2026-10-15] — Updated container published; callback failure isolated

- Confirmed Sou merged #120 as 1ab97deb185a4d2f645f54ae0fd4ebe964c67041. Main workflow 38722456917 passed check-and-build and registry publication. Sou's subsequent stage logs confirm the diagnostic image is deployed and receiving jobs.
- Ran one standalone container inference with the exact Naturalis media from the failed job, fixture job/MAS identifiers and the authenticated public GB10 endpoint. Corrected invocation passed in 101.234 seconds and produced 21 schema-valid annotations; artifacts copied locally to ignored mas/runs/integration-2026-10-15/self-test/outputs. Initial launcher attempt exited before inference. No RabbitMQ or sandbox submission, paid model call, model/prompt changes or biological accuracy claim.
- Supplied logs for SANDBOX/V6L-XSH-9EY identify HTTP 404 at notify_running, before image download/inference. URL construction matches current shared template and backend controller; backend can also return 404 when no MAS/job record matches. Requested the deployed non-secret RUNNING_ENDPOINT and MAS_ID values. Did not probe the state-changing callback or alter error handling while configuration is unverified.
- Updated current handoff/readiness notes. No source changes, commits, pushes or external messages in this follow-up.

## [2026-10-15] — Integration status rechecked at 12:00 BST

- Read both supplied media job lists: no newer TraitTrail attempt after SANDBOX/V6L-XSH-9EY; all five visible attempts remain failed. Protected public health returns 200 with configured=true, busy=false. GB10 logs show no new inference after our 11:47 BST standalone test. PR #120 remains merged.
- Saved a secret-free status summary under ignored mas/runs/integration-2026-10-15/status-check-1059.json and updated README. No new inference, sandbox scheduling, code changes, commits, pushes or external messages.

## [2026-10-15] — Wrong callback environment confirmed by organiser

- Jack forwarded Sou's 11:57 BST reply confirming RUNNING_ENDPOINT points to development instead of acceptance; she said she would fix it. No actual setting value received or deployment correction verified yet.
- Read-only recheck at 12:01 BST found no newer job on either supplied media record, no new completed inference and healthy/idle public GB10 API. Saved status-after-environment-diagnosis.json under ignored integration runs. Updated current readiness notes; no code/model changes, inference, live scheduling, commits or pushes.

## [2026-10-15] — Hackathon presentation copy reviewed

- Read the shared Google Slides deck's presentation brief and TraitTrail slides 10–11, including the existing workflow diagram. Prepared concise overview/workflow and closing copy for Jack to paste himself, plus an existing Studio human-review screenshot with image credit and saved-model context.
- Kept the distinction between structured predictions, human review and pending live sandbox acceptance. Suggested a result image and a short closing slide covering limits, production hosting and documentation lessons. No shared-slide edits, new presentation artifact, model calls, code changes, commits or pushes.

## [2026-10-15] — Advisory running-status fix submitted as PR #125

- New supplied job SANDBOX/4GV-8AD-L1A still fails at notify_running with HTTP 404. Confirmed its public record belongs to TraitTrail. Sou's reported environment mismatch does not establish the precise remaining cause; no actual deployed values received.
- Found an adapter-side behavioural difference: shared requests.get does not raise merely for HTTP 404, while our urllib call did. The developer guide recommends running-status reporting as an advisory feature. Added secret-safe WARNING handling for callback HTTP/network/timeouts, preserving strict download/inference/validation and publish-before-ack behaviour. Normalised a full https://hdl.handle.net/ MAS URI only for callback routing.
- Replaced the callback-abort regression with five continuation cases (401/404/503, network and timeout) and two Handle-form cases. All 32 tests pass on Python 3.12; Ruff lint/format and ARM64 Docker build pass. A network-isolated loopback HTTP test confirms real callback 404 permits 16 schema-valid fixture annotations, real inference 403 still fails, delivery ordering holds and logs exclude URLs/secrets. No VLM request or live sandbox submission.
- Continuing the authorised MAS integration PR work, committed/pushed 136cfee on plain branch traittrail-progress-callback, opened/attached #125. Found concurrent Sou hotfix #124 merged as f8d2757; its main workflow 38725404541 failed lint (unused running variable), so no updated image publication. Incorporated upstream in 338b198, replacing the temporary commented code with tested advisory behaviour and documenting it in the PR. Test-relevant files remain identical to the verified 136cfee tree. PR is open/mergeable; upstream CI/review/publication/deployment and a fresh job remain pending.
- No Studio source/model/prompt changes, credentials changes or messages sent to Sou. Updated readiness documentation and retained local test evidence.

- Final verification: upstream PR workflow 38725654684 passed check-and-build (32 tests, lint/format, locked dependencies, Docker build); PR publication correctly skipped. SonarCloud and SonarCloud Code Analysis both passed. PR #125 remains open/mergeable, source worktree clean; deployment/fresh sandbox success still unverified.

## [2026-10-15] — Callback fix merged/published; live target image inference succeeds

- Confirmed Sou merged #125 at 12:13 BST as a12dc51c767b7da1a19eadeb9dcc931ca57243e5. Main workflow 38725776577 passed both check-and-build and publish. Fresh job SANDBOX/LD4-K75-22Z targets media SANDBOX/B23-2JM-Y9Y.
- During read-only checks, GB10 became busy and completed a new request at 12:17:19 BST with HTTP 200. Request c09ce3fe77514347be76a7e8782e1cd1 / run_20150631de1047dc is usable with 16 observations and zero contract errors. Asset SHA-256 exactly matches the public job target's original Naturalis image (445df8c679974151e3042ad02b46e8028eb0cda4d78defdbec85872272e437bb; 2,362,600 bytes). No inference or sandbox job was initiated by the assistant.
- At 12:18:44 BST the public job still shows SCHEDULED, no error or annotation IDs. Requested post-inference pod logs to distinguish mapping/publication from downstream processing. Exact deployed image digest and complete sandbox acceptance remain unverified; no accuracy claim. Saved secret-free status/hash correlation under ignored integration runs and updated current notes. No code changes, commits, pushes or external messages.

## [2026-10-15] — Annotation-selector compatibility fix submitted as PR #126

- Latest supplied logs confirm LD4-K75-22Z and BR5-5T2-FYD continue after the running-status 404 and complete inference, mapping and confirmed broker publication/acknowledgement. At 12:34 BST both public jobs still show SCHEDULED with null completion/annotations/error. Awaiting DiSSCo annotation-processing logs; actual deployed downstream exception remains unverified.
- Reproduced a compatibility defect from the retained live output and official processor source: four unlocalized annotations omit selectors that the processor dereferences; shared selector identities can collide. Added explicit root class selectors and grouped body values for the same selector, preserving predictions, evidence, uncertainty and model/run provenance without inventing regions for unknowns.
- Validation: 34 Python 3.12 tests, Ruff lint/format and ARM64 Docker build pass. Network-isolated actual-result replay changes 20 requests to 14 while preserving all 20 body values/all 16 features, schema validity and unique processor identities. No new VLM call, paid API use or DiSSCo submission.
- Continuing authorised integration fixes, committed/pushed only the four reviewed adapter/workflow files as 6d42d0c on traittrail-annotation-selectors; opened/attached PR #126. Fork workflow 38727906322 and upstream 38727920118 pass; both SonarCloud checks pass, PR publication correctly skipped. PR remains open/mergeable; merge/deployment and live acceptance pending. Studio importer compatibility changes are local only; all 17 JavaScript tests and actual-response comparison pass. No service/model/prompt changes or messages sent to Sou.

## [2026-10-15] — Selector fix merged and container published

- Read-only check confirms PR #126 merged as 955dbbd0ae2d9726f39b705763d0851bf508f032 at 12:36 BST. Main workflow 38728561989 passed check-and-build and registry publication, completing at 12:37 BST. No new code changes or test reruns were needed.
- At 12:37 BST both existing LD4/BR5 public job records remain SCHEDULED with no annotations/completion/error. The target media job list has no newer TraitTrail attempt; GB10's last inference remains the 12:20 BST successful response. Deployment of the new image, a fresh accepted job and downstream processor logs remain unverified. Updated local status records; no model request, sandbox submission, commit/push or external message.

## [2026-10-15] — Fresh live image test through updated adapter

- At Jack's request ran the updated PR #126 adapter container against the actual B23-2JM-Y9Y media image and protected public ngrok/Qwen endpoint. Standalone run completed at 12:44 BST in 104.121 seconds: 16 features, 19 feature/region body values, 12 grouped annotations. Full pinned schema, every selector and unique processor identities pass. Retained JSON/logs/report/verification under ignored integration runs; no model/prompt change or paid API call.
- Attempted one full sandbox test through Digital Media → Machine Annotation Services → Schedule a MAS → TraitTrail specimen observations. Browser was signed out; Schedule returned “Failed to schedule MASs. Please try again.” No newer job appeared on the public media job list; exact scheduling HTTP cause unverified. Opened ORCID sign-in and asked Jack to sign in so a fresh scheduling attempt can proceed. Standalone test does not establish DiSSCo acceptance. No code change, commit/push or external message.

## [2026-10-15] — First complete DiSSCo sandbox job verified

- Jack signed in with ORCID after the initial signed-out scheduling failure. Retried the authorized test through the sandbox UI; one TraitTrail job was created: SANDBOX/F1G-YFN-P39, targeting media B23-2JM-Y9Y. GB10 returned HTTP 200 at 12:48:31 BST; DiSSCo marked the job COMPLETED at 12:49:17 BST with no error and eight annotation Handles (about 2 minutes 36 seconds total).
- Read the saved annotations through the official digital-media annotations API, whose route was verified in DiSSCo/disscover source. All eight records are readable and contain all 16 expected features, 17 feature/region body values, selectors and Qwen model/run provenance (run_5538dd38417b4dc0). All human_reviewed flags remain false; the proposals await expert review. This verifies complete sandbox delivery and the new grouped output, not biological accuracy or the exact deployed pod digest.
- Saved public job/annotation readback, verification, live standalone JSON and the successful UI screenshot under ignored integration runs. Left the signed-in result page open and reset the temporary viewport. No source/model/prompt change, paid API use, commit/push or external message. Updated current project status to reflect verified MAS completion; Studio's direct job retrieval and application publication remain future work.

## [2026-10-15] — Completed job opened in Studio

- Exported exactly the eight annotation records referenced by completed job F1G-YFN-P39, preserving their attributes. Paired them with the unchanged original Naturalis image and verified source hash; bundle and provenance are local/ignored in Studio.
- Studio now accepts saved JSON:API annotation collections directly in Results/review folders. All 19 JavaScript tests and actual-result equivalence/folder checks pass; all 16 features are visible. Browser verification confirms two antenna regions and no box for an unknown wing count. No Capture/MAS source change, new inference, submission, human-review decision, commit or push.

## [2026-10-15] — Read-only usage and access review

- Reviewed the retained GB10 request log, current service health and known sandbox media job lists at 13:09–13:12 BST. No new inference after our 12:48:31 BST completed sandbox test; all six successful inference requests match recorded tests. Service idle. Full DiSSCo cross-user queue visibility and caller attribution are unavailable from this service log, so this does not exclude jobs waiting elsewhere.
- Public health rejects missing/wrong bearer keys (403) and accepts the configured key (200). API/Ollama/ngrok management/Studio bind loopback; the single tunnel forwards only the API, with local inspection disabled. Secret configuration files are mode 600. Exact token-value checks against public MAS metadata and annotations were negative; no secret values printed. Current MAS uses local Qwen and does not spend OpenRouter credit.
- Verified the live registered filter restricts digital media to Naturalis Lepidoptera source SANDBOX/07R-Y6E-JYA, with one replica and batching disabled. This filters objects, not individual users. Official backend source requires authenticated ORCID scheduling; public annotation reads remain possible. Value service has no daily/per-user quota or caller/job attribution, and direct key holders bypass platform dataset filtering. Recorded workload/availability limits as the remaining shared-service concern.
- Preserved safe verification summaries in ignored access-review runs and refreshed current README/project status. No access/credential changes, model calls, paid requests, code changes, commit/push or external messages. Validation was read-only state/code review plus non-inference health checks; no code tests needed.

## [2026-10-15] — One-hour public-access shutdown scheduled

- Jack explicitly requested another hour of availability followed by disabling public access. Created active thread heartbeat disable-traittrail-public-access, due about 14:18 BST, to stop only the TraitTrail ngrok tunnel on GB10 and verify the public endpoint is offline. Local API, Ollama/model, other tunnels and GB10 remain running; no credential or DiSSCo registration changes authorized/attempted.
- The automation is a one-time shutdown and will deactivate itself after verified completion. Current public access remains on. Verified the saved automation's active status, target thread and one-hour schedule; updated availability notes. No code changes, inference, immediate service shutdown, commits or pushes.

## [2026-10-15] — Studio preparation and separate hackathon archive

- At Jack's request separated Studio's current product guide from hackathon history. Preserved its earlier README, detailed development log, distribution/integration research, naming notes and original validation record in docs/hackathon/studio/, with an archive index. Fixed the deployed adapter walkthrough link and documented that this repository's original wrapper predates the current upstream adapter fixes.
- Studio now has the approved MIT software licence, separate photograph permissions, user-owned local/API setup, curated completed DiSSCo and four-brand examples, a source ZIP builder and manual-only static viewer publication. Raw/rejected working evidence and actual keys remain ignored. The graph code is retained and its UI stays paused.
- Validation: Capture's 98 offline tests, saved-demo's 104 tests and the 19 prototype MAS tests pass using Python 3.12. Studio's 23 Python and 20 JavaScript tests pass, including a fresh installed download; browser upload/synthetic analysis, evidence display and review save/resume pass. No new model or paid API call. Configured secret-value checks find no matches in the selected source. Docker is unavailable on this workstation; the private MAS workflow includes its container build.
- Jack authorised committing and pushing the current TraitTrail work for private GitHub review. Both repositories were verified private; no public visibility, Pages publication or live-service configuration change is included. The previously scheduled tunnel shutdown remains active and unchanged.

## [2026-10-15] — Personal introduction and separate technical/history pages

- Replaced the 816-line front page with a short first-person introduction,
  one original scanner image, a saved-viewer entrypoint and links to the code,
  data, graph and research material. Preserved the research authorship and
  model/evidence limitations without opening with the formal manuscript title.
- Preserved the previous front page in docs/hackathon/development-notes.md with
  a historical-status notice and adjusted relative links. Added a short hackathon
  summary containing the successful sandbox job and temporary hosting plan.
- Moved the dated integration review out of the scanner method guide into
  docs/hackathon/integration-review.md. No image bytes, saved runs, application,
  model, hardware or scheduled shutdown settings were changed.
- Validation: all 62 checked local documentation/image targets and section links
  resolve. Compared the archived front page with its Git version and confirmed
  that every paragraph is retained; only relative link targets and the archive
  notice differ. Scanner/model tests were not repeated for documentation changes.
