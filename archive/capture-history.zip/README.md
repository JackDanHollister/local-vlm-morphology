# TraitTrail Capture

Here's my attempt at getting a small specimen scanner to do a bit more than
take photographs.

I've been using a modified OpenScan Mini to collect different views of a
specimen, then asking vision models about visible features such as wings,
legs and antennae. I wanted to keep each answer connected to the images and
regions it came from, so I could go back and check it.

This is where the scanner code, saved scans and research notes live. The
standalone image-analysis app now has its own home:
[TraitTrail Studio](https://github.com/JackDanHollister/traittrail-studio).

<img src="saved-demo/demo/scans/demo_87513f98533740e4/assets/acba0900dd017a7c79352a9354df156bf6938cff0a4de7a8bde259bbefb037dd.png" alt="A beetle photographed during one of the scanner runs" width="360">

*One of my scanner images, kept as its original crop from saved scan 5.*

## What I've been trying

The scanner takes **40 views per run**. The pipeline then records the images,
crops, model answers and suggested evidence regions. These can be inspected
in a viewer or linked together in a graph.

There are **five saved scans** here: 200 original photographs, 196 crops and
all 40 model responses, including five failed batches. Those scanner examples
used `gpt-6-astra`; the later DiSSCo demo used Qwen3.8. The individual runs and
model details are kept with the results.

## Have a look

You can browse the saved scans without a scanner, GPU or API key. From a
cloned or downloaded copy of this repository, with Python installed:

```sh
cd saved-demo
./start-demo.sh
```

Open **http://127.0.0.1:8765/**. The viewer restores a working copy of a saved
scan so you can follow the observations back to their images.
[More about the saved data](data/README.md).

If you want to add your own photos or try different models, start with
[Studio](https://github.com/JackDanHollister/traittrail-studio).

## The DiSSCo hackathon

I took this into the DiSSCo MAS hackathon and got the image-observation service
working through their sandbox. A completed job returned all 16 feature
observations, with image regions and model details, as annotation proposals.

The current adapter lives in
[DiSSCo's service repository](https://github.com/DiSSCo/demo-enrichment-service-image/tree/main/traittrail-specimen-observation).
The original value service and prototype wrapper are kept here in [mas/](mas/README.md).
The [hackathon summary](docs/hackathon/README.md) has the completed job, temporary
hosting notes and links to the development history.

## What's in here

| Folder | What's there |
|---|---|
| [capture/](capture/) | Scanner control, firmware and the original rig configuration. |
| [saved-demo/](saved-demo/README.md) | The five scans, saved model outputs and replay viewer. |
| [data/](data/README.md) | A guide to the images and records. |
| [additional/specimen-feature-graph/](additional/specimen-feature-graph/HANDOFF.md) | The separate 590-butterfly graph experiment. Its map localities are simulated. |
| [docs/](docs/project-breakdown.md) | How it works, evidence, limitations and research notes. |

## Still working on

I still need to finish the paper companion, settle its exact model/evidence
baseline and evaluate the observations against human judgements. The saved
results are research examples awaiting expert review.

The original rig's calibration is included for reference; another scanner
needs its own setup. [Hardware notes](capture/docs/hardware.md).

For the deeper details, see [how the scanner experiment works](docs/project-breakdown.md),
[evidence and limitations](docs/evidence-and-limitations.md),
[completion status](docs/completion-status.md) and [source provenance](PROVENANCE.md).
Code/data licensing and archival publication are still being finalised;
the [shared test-image set](https://jackdanhollister.github.io/traittrail-test-images/)
has its own per-image credits and permissions.

This research companion supports *Agentic AI Systems for Specimen Interaction
and Camera-Based Observation*, by Jack D. Hollister and Steen Dupont,
Natural History Museum, London. [Citation details](CITATION.cff).
